================================================================================
     MICROSOFT FOUNDATION CLASS LIBRARY : libzkfpDemo Project Overview
===============================================================================

The application wizard has created this libzkfpDemo application for you. This application not only demonstrates the basics of using Microsoft Foundation Classes, but also serves as a starting point for writing applications.

This file contains a summary of the contents of the various files that make up the libzkfpDemo application.

libzkfpDemo.vcproj
   This is the main project file for a VC++ project generated using the AppWizard.
    It contains information about the Visual C++ version of the generated file and information about the platform, configuration, and project features selected using the AppWizard.

libzkfpDemo.h
    This is the main header file for the application. It includes other project-specific header files (including Resource.h) and declares the ClibzkfpDemoApp application class.

libzkfpDemo.cpp
   This is the main application source file that contains the application class ClibzkfpDemoApp.
libzkfpDemo.rc
    This is a list of all the Microsoft Windows resources that the program uses. It includes icons, bitmaps, and cursors stored in the RES subdirectory. This file can be edited directly in Microsoft Visual C++. The project resources are located in 2052.

res\libzkfpDemo.ico
    This is an icon file that is used as an application icon. This icon is included in the main resource file libzkfpDemo.rc.

res\libzkfpDemo.rc2
    This file contains resources that are not edited by Microsoft Visual C++. You should place all resources that are not editable by the resource editor in this file.

/////////////////////////////////////////////////////////////////////////////

The application wizard creates a dialog class:

libzkfpDemoDlg.h, libzkfpDemoDlg.cpp - dialog
    These files contain the ClibzkfpDemoDlg class. This class defines the behavior of the application's main dialog. The template for this dialog is located in libzkfpDemo.rc, which can be edited in Microsoft Visual C++.


/////////////////////////////////////////////////////////////////////////////

Other functions:
ActiveX control
    Applications include support for using ActiveX controls.

Print and print preview support
    The Application Wizard has generated code for processing print, print settings, and print preview commands by calling member functions from the MView library in the CView class.

/////////////////////////////////////////////////////////////////////////////

Other standard documents:

StdAfx.h, StdAfx.cpp
    These files are used to generate a precompiled header (PCH) file named libzkfpDemo.pch and a precompiled type file named StdAfx.obj.

Resource.h
    This is the standard header file that defines the new resource ID.
    Microsoft Visual C++ will read and update this file.

libzkfpDemo.manifest
	Windows XP uses an application manifest file to describe the application's dependencies on a particular version of a parallel assembly. The loader uses this information to load the appropriate assembly from the assembly cache or to load private information from the application. The application manifest may be included as an external .manifest file installed in the same folder as the application executable for republishing, or it may be included as a resource in the executable.
/////////////////////////////////////////////////////////////////////////////

Other notes:

The Application Wizard uses "TODO:" to indicate the source code portion that should be added or customized.

If your application uses MFC in a shared DLL, you will need to republish the MFC DLL. If the application uses a different locale than the operating system, the corresponding localized resource MFC90XXX.DLL will also have to be republished.
For more information on these two topics, see the section on republishing Visual C++ applications in the MSDN documentation.
/////////////////////////////////////////////////////////////////////////////