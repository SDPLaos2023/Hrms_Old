//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Demo.rc
//
#define IDD_DEMO_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDC_ZKFPENGX2                   1001
#define IDC_EDTCOUNT                    1002
#define IDC_EDTCUR                      1003
#define IDC_EDTSN                       1005
#define IDC_BTNInit                     1006
#define IDC_BTNSave                     1007
#define IDC_BTNInit2                    1008
#define IDC_BTNDisConnect               1008
#define IDC_RADIOBMP                    1010
#define IDC_RADIOJPG                    1011
#define IDC_BTNReg                      1012
#define IDC_BTNVer                      1013
#define IDC_BTNIdentify                 1014
#define IDC_EDReg                       1015
#define IDC_EDTHINT                     1016
#define IDC_CUSTOM1                     1017
#define IDC_BTNREGBYIMAGE               1017
#define IDC_BTNVerFromFile              1018
#define IDC_BTNIDENBYIMAGE              1018
#define IDC_BTNSN                       1023
#define IDC_BTNCARDNUMBER               1025
#define IDC_BTNREAD                     1026
#define IDC_BTNWRITE                    1027
#define IDC_EDIT_Block                  1029
#define IDC_EDIT_WriteBlock             1030
#define IDC_EDIT3                       1031
#define IDC_BUTTON5                     1032
#define IDC_BTNWRITETMP                 1032
#define IDC_EDIT_FINGERPIN              1034
#define IDC_BUTTON6                     1036
#define IDC_BTNREADTMP                  1036
#define IDC_PINWIDE5                    1040
#define IDC_BTNRED                      1048
#define IDC_BTNGREEN                    1049
#define IDC_BTNBEEP                     1050
#define IDC_BTNWRITEPWD                 1051
#define IDC_BTNREADPWD                  1052
#define IDC_RADIO9                      1053
#define IDC_RADIO10                     1054
#define IDC_CHECK1                      1056
#define IDC_CHK_FAKEFNON                1056

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1057
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
