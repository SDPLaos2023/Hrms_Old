//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ZKFVDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDB_BITMAP1                     213
#define IDB_BITMAP2                     215
#define IDB_BITMAP_FV                   215
#define IDC_BTN_CLOSE                   1000
#define IDC_EDIT_USERID                 1003
#define IDC_STATIC_SN                   1007
#define IDC_STATIC_DATE                 1008
#define IDC_STATIC_REPORT               1009
#define IDC_BTN_CONN                    1010
#define IDC_BTN_IDENTIFY                1011
#define IDC_BTN_DISCONN                 1012
#define IDC_BTN_VERIFY                  1013
#define IDC_BTN_ENROLL                  1014
#define IDC_COMBO1                      1015
#define IDC_STATIC_UID                  1016
#define IDC_STATIC_IMODE                1017
#define IDC_EDIT_REPORT                 1018
#define IDC_BTN_ENROLL2                 1019
#define IDC_BTN_CLEAR                   1019
#define IDC_BUTTON1                     1020
#define IDC_BTN_P                       1020
#define IDC_BTN_DEVPARAM                1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        216
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
