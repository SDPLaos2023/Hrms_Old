
// ZKFPDemo3Dlg.h : ͷ�ļ�
//

#pragma once


#include "head&lib\include\zkfvapi.h"
#include "head&lib\include\zkfvapierrdef.h"
#include "head&lib\include\zkfvapitype.h"

// CZKFPDemo3Dlg �Ի���
class CZKFPDemo3Dlg : public CDialog
{
// ����
public:
	CZKFPDemo3Dlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_ZKFPDEMO3_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

	static DWORD WINAPI ThreadCapture(LPVOID lParam);
// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();


private:
	CButton  	m_bnClose;
	CButton	 	m_bnConn;
	CButton	 	m_bnDisConn;
	CButton	 	m_bnEnroll;
	CButton	 	m_bnVerify;
	CButton	 	m_bnIdentify;
	CButton	 	m_bnClear;
	CButton	 	m_bnTest;
	CComboBox	m_cbMode;
	CComboBox   m_cbEnMode;
	CStatic     m_cPicFingerPrint;
	CStatic     m_cPicFingerVien;
	CFont cfont;
	CString     EditData;
public:
	afx_msg void OnBnClickedBtnConn();
	LRESULT OnMsgFingerReceived(WPARAM wParam, LPARAM lParam);
	LRESULT OnMsgVeinReceived(WPARAM wParam, LPARAM lParam);
	
	afx_msg void OnCbnSelchangeCombo1();
	afx_msg void OnEnChangeEdit1();
public:
	HANDLE	 m_hDevice;
	HANDLE	 m_hDBCache;
	HANDLE	 m_hThreadWork;
	int 	 m_imgFPWidth;
	int 	 m_imgFPHeight;
	int 	 m_imgFVWidth;
	int 	 m_imgFVHeight;


	unsigned char** m_preRegFPTmps;
	int				m_nPreRegFPTmpSize[3];
	unsigned char** m_preRegFVTmps;
	int				m_nPreRegFVTmpSize[3];
	int				m_nEnrollIndex;


	//verify sample
	unsigned char** m_lastRegFPTmps;
	int				m_nlastRegFPTmpSize[3];
	unsigned char** m_lastRegFVTmps;
	int				m_nlastRegFVTmpSize[3];

		//�Ǽ�ͼƬ�Ĵ��
	unsigned char ** m_regFpImage;
	int				 m_nregFpImageSize[3];
	unsigned char ** m_regFvImage;
	int				 m_nregFvImageSize[3];


	unsigned char  * m_NowImage_FV;
	unsigned char  * m_NowImage_FP;

	BOOL m_bIdentify;
	BOOL m_bStopThread;
	BOOL m_bRegister;
	
	CString m_strFingerID;
private:
	void 	DoRegister(unsigned char* fpTmp, int cbFPTmp, unsigned char* fvTmp, int cbFVTmp,unsigned char * fpImg,int fpImgSize, unsigned char * fvImg,int fvImgSize);
	void 	DoVerify(unsigned char* fpTmp, int cbFPTmp, unsigned char* fvTmp, int cbFVTmp);
	int	 	GetIdentifyMode(unsigned char Num);
	void 	HY_Register(unsigned char* fpTmp, int cbFPTmp, unsigned char* fvTmp, int cbFVTmp,unsigned char * fpImg,int fpImgSize, unsigned char * fvImg,int fvImgSize);
	void 	FV_Register(unsigned char* fpTmp, int cbFPTmp, unsigned char* fvTmp, int cbFVTmp,unsigned char * fpImg,int fpImgSize, unsigned char * fvImg,int fvImgSize);
	void 	FP_Register(unsigned char* fpTmp, int cbFPTmp, unsigned char* fvTmp, int cbFVTmp,unsigned char * fpImg,int fpImgSize, unsigned char * fvImg,int fvImgSize);
	void 	DebugLog(CString &CS);
	CString FUN_Char2CString(char *ch1, char * ch2);
public:
	afx_msg void OnBnClickedBtnDisconn();
	afx_msg void OnBnClickedBtnEnroll();
	afx_msg void OnBnClickedBtnVerify();
	afx_msg void OnBnClickedBtnIdentify();
	afx_msg void OnBnClickedBtnClear();
	afx_msg void OnBnClickedBtnTest();
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
	
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton5();
	afx_msg void OnBnClickedButton6();
	afx_msg void OnBnClickedButton7();
	afx_msg void OnBnClickedButton8();
	afx_msg void OnBnClickedButton9();
};