#ifndef _ZKFINGER_VEIN_COMMON_H_
#define _ZKFINGER_VEIN_COMMON_H_

#include<string.h>

void char2wchar( wchar_t * dest, char * src, int lim);

int byte2hex(const unsigned char *input, unsigned long inlen, unsigned char *output, unsigned long *outlen);

int WriteBitmapHeader(BYTE *Buffer, int Width, int Height);

int WriteBitmap(BYTE *buffer, int Width, int Height, char *file);

HBITMAP BuildImage(BYTE *image, int width, int height);

int  Zoom(BYTE *lpSrcDib,BYTE *lpDstDib, long lWidth, long lHeight,
	long lDstWidth,long lDstHeight);

void rotate90(BYTE *Srcbmp, BYTE *Dstbmp,int width, int height);

BOOL is_digit(const TCHAR *str);
void ConvertImage( unsigned char *src,unsigned char *dst,int sw,int sh,int width,int height,int rotaImage);

#endif	//_ZKFINGER_VEIN_COMMON_H_



class CBase64Coder
{
private :
        static char ch64[];
        char* buf;
        int size ;

private :
        static int BinSearch(char p);
        void allocMem(int NewSize);

public :
        CBase64Coder();
        ~CBase64Coder();
        const char* encode(const unsigned char* buffer,int buflen);
        const char* decode(const char* buffer,int Length);

};