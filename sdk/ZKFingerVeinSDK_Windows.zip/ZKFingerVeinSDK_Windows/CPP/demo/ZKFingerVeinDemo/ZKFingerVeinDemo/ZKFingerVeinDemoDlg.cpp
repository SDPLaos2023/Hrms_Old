
// ZKFPDemo3Dlg.cpp : Implementation file
//

#include "stdafx.h"
#include "ZKFingerVeinDemo.h"
#include "ZKFingerVeinDemoDlg.h"
#include "common.h"



#ifndef _WIN64
#pragma comment(lib, "head&lib/x86lib/zkfvapi.lib")
#else
#pragma comment(lib, "libzkfv/x64lib/zkfvapi.lib")
#endif

#define WM_FINGER_RECEIVED		(WM_USER+103)
#define WM_VEIN_RECEIVED		(WM_USER+104)

#define ENROLL_CNT	3
CString g_app_path = _T("");

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog for the application About menu item

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// achieve
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CZKFPDemo3Dlg Dialog







CZKFPDemo3Dlg::CZKFPDemo3Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CZKFPDemo3Dlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDD_MAINDLG);
}

void CZKFPDemo3Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CZKFPDemo3Dlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, &CZKFPDemo3Dlg::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CZKFPDemo3Dlg::OnBnClickedCancel)
	ON_BN_CLICKED(IDC_BTN_CONN, &CZKFPDemo3Dlg::OnBnClickedBtnConn)
	ON_CBN_SELCHANGE(IDC_COMBO1, &CZKFPDemo3Dlg::OnCbnSelchangeCombo1)
	ON_EN_CHANGE(IDC_EDIT1, &CZKFPDemo3Dlg::OnEnChangeEdit1)
	ON_MESSAGE(WM_FINGER_RECEIVED,OnMsgFingerReceived)
	ON_MESSAGE(WM_VEIN_RECEIVED,OnMsgVeinReceived)
	ON_BN_CLICKED(IDC_BTN_DISCONN, &CZKFPDemo3Dlg::OnBnClickedBtnDisconn)
	ON_BN_CLICKED(IDC_BTN_ENROLL, &CZKFPDemo3Dlg::OnBnClickedBtnEnroll)
	ON_BN_CLICKED(IDC_BTN_VERIFY, &CZKFPDemo3Dlg::OnBnClickedBtnVerify)
	ON_BN_CLICKED(IDC_BTN_IDENTIFY, &CZKFPDemo3Dlg::OnBnClickedBtnIdentify)
	ON_BN_CLICKED(IDC_BTN_CLEAR, &CZKFPDemo3Dlg::OnBnClickedBtnClear)
	ON_BN_CLICKED(IDC_BUTTON1, &CZKFPDemo3Dlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CZKFPDemo3Dlg::OnBnClickedButton2)

	ON_BN_CLICKED(IDC_BUTTON3, &CZKFPDemo3Dlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON5, &CZKFPDemo3Dlg::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON6, &CZKFPDemo3Dlg::OnBnClickedButton6)
	ON_BN_CLICKED(IDC_BUTTON7, &CZKFPDemo3Dlg::OnBnClickedButton7)
	ON_BN_CLICKED(IDC_BUTTON8, &CZKFPDemo3Dlg::OnBnClickedButton8)
	ON_BN_CLICKED(IDC_BUTTON9, &CZKFPDemo3Dlg::OnBnClickedButton9)
END_MESSAGE_MAP()


// CZKFPDemo3Dlg Message handler

BOOL CZKFPDemo3Dlg::OnInitDialog()
{
	//MoveWindow(0, 0, 600, 720);
	CDialog::OnInitDialog();

	 this->SetWindowTextW(_T("ZKFingerVeinDemo v0.2"));
	 this->ShowWindow(SW_SHOW);
	 this->UpdateWindow();


	 EditData.Empty();

	// Add the "About..." menu item to the system menu.

	// IDM_ABOUTBOX Must be within the scope of the system command.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog. The framework will do this automatically 
      //when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icons

	
	m_bnConn.SubclassDlgItem(IDC_BTN_CONN,this);
	m_bnEnroll.SubclassDlgItem(IDC_BTN_ENROLL,this);
	m_bnVerify.SubclassDlgItem(IDC_BTN_VERIFY,this);
	m_bnDisConn.SubclassDlgItem(IDC_BTN_DISCONN,this);
	m_bnIdentify.SubclassDlgItem(IDC_BTN_IDENTIFY,this);
	m_bnTest.SubclassDlgItem(IDC_BTN_TEST,this);
	m_bnClear.SubclassDlgItem(IDC_BTN_CLEAR,this);


	m_cbMode.SubclassDlgItem(IDC_COMBO1,this);
	m_cbMode.AddString(_T("Normal Hybrid Identify"));
	m_cbMode.AddString(_T("Fake Hybrid Identify"));
	m_cbMode.AddString(_T("Security Hybrid Identify"));
	m_cbMode.AddString(_T("Single Identify"));
	m_cbMode.SetCurSel(0);

	m_cbEnMode.SubclassDlgItem(IDC_COMBO2,this);
	m_cbEnMode.AddString(_T("Hybrid Enroll"));
	m_cbEnMode.AddString(_T("FV Enroll"));
	m_cbEnMode.AddString(_T("FP Eroll"));
	m_cbEnMode.SetCurSel(0);
	
	m_cPicFingerVien.SubclassDlgItem(IDB_BITMAP2,this);
	m_cPicFingerPrint.SubclassDlgItem(IDB_BITMAP1,this);


	m_NowImage_FV=NULL;
	m_NowImage_FP=NULL;

	
	cfont.CreatePointFont(100,_T("Arial"),NULL);
	GetDlgItem(IDC_EDIT_REPORT)->SetFont(&cfont);



	m_bIdentify = TRUE;
	m_bRegister = FALSE;
	m_hDBCache = NULL;
	m_hDevice = NULL;
	m_bStopThread = FALSE;
	m_hThreadWork = NULL;

	m_preRegFPTmps = NULL;
	m_preRegFVTmps = NULL;
	m_lastRegFPTmps = NULL;
	m_lastRegFVTmps = NULL;
	m_regFpImage = NULL;
	m_regFvImage = NULL;



	return TRUE;  // Returns TRUE unless the focus is set to the control
}

/*
#define IDM_ABOUTBOX                    0x0010
#define xBtnPos                         42
#define IDD_ABOUTBOX                    100
#define yBtnSapce                       100
#define IDS_ABOUTBOX                    101
#define IDD_ZKFPDEMO3_DIALOG            102
#define xBtnSpace                       105
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDB_PNG1                        130
#define IDB_PNG2                        131
#define IDB_PNG3                        132
#define IDB_PNG4                        133
#define IDB_BITMAP3                     134
#define IDB_PNG5                        135
#define IDB_PNG6                        136
#define IDB_PNG7                        137
#define IDB_PNG8                        138
#define IDB_PNG9                        139
#define IDB_PNG10                       140
#define IDB_PNG11                       141
#define IDB_BITMAP1                     213
#define IDB_BITMAP2                     215
#define IDB_BITMAP_FV                   215
#define yBtnPos                         464
#define IDC_BTN_CLOSE                   1000
#define IDC_BUTTON2                     1001
#define IDC_BUTTON3                     1002
#define IDC_BUTTON4                     1003
#define IDC_EDIT_USERID                 1003
#define IDC_BUTTON5                     1004
#define IDC_BUTTON6                     1005
#define IDC_BUTTON7                     1006
#define IDC_STATIC_SN                   1007
#define IDC_STATIC_DATE                 1008
#define IDC_STATIC_REPORT               1009
#define IDC_BTN_CONN                    1010
#define IDC_BTN_IDENTIFY                1011
#define IDC_BTN_DISCONN                 1012
#define IDC_BTN_VERIFY                  1013
#define IDC_BTN_ENROLL                  1014
#define IDC_COMBO1                      1015
#define IDC_STATIC_UID                  1016
#define IDC_STATIC_IMODE                1017
#define IDC_EDIT_REPORT                 1018
#define IDC_BTN_ENROLL2                 1019
#define IDC_BTN_CLEAR                   1019
#define IDC_BUTTON1                     1020
#define IDC_BTN_P                       1020
#define IDC_BTN_DEVPARAM                1020
#define IDC_BTN_TEST                    1025
#define IDC_BTN_TEST1                   1026
*/
void CZKFPDemo3Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to the dialog, you need the following code to //draw the icon. For MFC applications that use the document/view model, 
//this will be done automatically by the framework.

void CZKFPDemo3Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // Device context for drawing

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center the icon in the workspace rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

//The system calls this function to get the cursor display 
//when the user drags the minimized window.
HCURSOR CZKFPDemo3Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CZKFPDemo3Dlg::OnBnClickedOk()
{
	// TODO: Add control notification handler code here
	OnOK();
}

void CZKFPDemo3Dlg::OnBnClickedCancel()
{
	// TODO: Add control notification handler code here
	OnCancel();
}

int CZKFPDemo3Dlg::GetIdentifyMode(unsigned char Num)
{
	int nSel=0;
	switch(Num)
	{
	case 1:
		nSel = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();
		break;
	case 2:
		nSel = ((CComboBox*)GetDlgItem(IDC_COMBO2))->GetCurSel();
		break;
	}
	if (- 1 == nSel)
	{
		nSel = 0;
	}
	return nSel;
}

void CZKFPDemo3Dlg::HY_Register(unsigned char* fpTmp, int cbFPTmp, unsigned char* fvTmp, int cbFVTmp,unsigned char * fpImg,int fpImgSize, unsigned char * fvImg,int fvImgSize)
{
	if (cbFPTmp > 0 && cbFVTmp > 0)	//fingerprint and fingervein capture success
		{
			if (m_nEnrollIndex > 0)
			{
				if (ZKFingerVein_Verify(m_hDevice, BIO_TYPE_FP, fpTmp, cbFPTmp, m_preRegFPTmps[m_nEnrollIndex-1], m_nPreRegFPTmpSize[m_nEnrollIndex-1]) <= 0 ||
					ZKFingerVein_Verify(m_hDevice, BIO_TYPE_FV, fvTmp, cbFVTmp, m_preRegFVTmps[m_nEnrollIndex-1], m_nPreRegFVTmpSize[m_nEnrollIndex-1]) <= 0)
				{
				//	SetDlgItemText(IDC_EDIT_REPORT, _T("Enroll failed!"));
					DebugLog(CString("Enroll failed!"));
					m_bRegister = FALSE;
					m_nEnrollIndex = 0;
				}
			}
			memcpy(m_regFpImage[m_nEnrollIndex],fpImg,fpImgSize);
			m_nregFpImageSize[m_nEnrollIndex] = fpImgSize;
			memcpy(m_regFvImage[m_nEnrollIndex],fvImg,fvImgSize);
			m_nregFvImageSize[m_nEnrollIndex] = fvImgSize;
			memcpy(m_preRegFPTmps[m_nEnrollIndex], fpTmp, cbFPTmp);
			m_nPreRegFPTmpSize[m_nEnrollIndex] = cbFPTmp;
			memcpy(m_preRegFVTmps[m_nEnrollIndex], fvTmp, cbFVTmp);
			m_nPreRegFVTmpSize[m_nEnrollIndex] = cbFVTmp;
			m_nEnrollIndex++;
			if (m_nEnrollIndex >= 3)
			{
				int ret = 0; 
				size_t len = wcslen(m_strFingerID.GetBuffer()) + 1;
				size_t converted = 0;
				char *CStr;
				CStr=(char*)malloc(len*sizeof(char));
				wcstombs_s(&converted,CStr,len,m_strFingerID.GetBuffer(),_TRUNCATE);
				if (ZKFV_ERR_OK == (ret = ZKFingerVein_DBAdd(m_hDBCache, BIO_TYPE_FP, CStr , m_preRegFPTmps, ENROLL_CNT)) &&
					ZKFV_ERR_OK == (ret = ZKFingerVein_DBAdd(m_hDBCache, BIO_TYPE_FV, CStr, m_preRegFVTmps, ENROLL_CNT)))
				{
					DebugLog(CString("Enroll Succ!"));	
					/*m_NowImage_FP=new unsigned char[m_imgFPWidth * m_imgFPHeight];
					m_NowImage_FV=new unsigned char[m_imgFVWidth * m_imgFVHeight];
					memcpy(m_NowImage_FP,fpImg,fpImgSize);
					memcpy(m_NowImage_FV,fvImg,fvImgSize);*/
					//save Last register featue, to verify sample
					for (int i=0;i<ENROLL_CNT;i++)
					{
						m_nlastRegFPTmpSize[i] = m_nPreRegFPTmpSize[i];
						m_nlastRegFVTmpSize[i] = m_nPreRegFVTmpSize[i];
						memcpy(m_lastRegFPTmps[i], m_preRegFPTmps[i], m_nPreRegFPTmpSize[i]);
						memcpy(m_lastRegFVTmps[i], m_preRegFVTmps[i], m_nPreRegFVTmpSize[i]);
					}
				}
				else
				{
					CString strLog;
					strLog.Format(_T("ZKFingerVein_DBAdd failed, ret=%d\r\n"), ret);
					DebugLog(strLog);
					//SetDlgItemText(IDC_EDIT_REPORT, strLog);
				}
				m_bRegister = FALSE;
				m_nEnrollIndex = 0;
			}
			else
			{
				CString strLog;
				strLog.Format(_T("You need press your finger %d times\r\n"), ENROLL_CNT-m_nEnrollIndex);
				DebugLog(strLog);
				//SetDlgItemText(IDC_EDIT_REPORT, strLog);
			}
		}

}
void CZKFPDemo3Dlg::FV_Register(unsigned char* fpTmp, int cbFPTmp, unsigned char* fvTmp, int cbFVTmp,unsigned char * fpImg,int fpImgSize, unsigned char * fvImg,int fvImgSize)
{
	if (cbFVTmp > 0)	//fingerprint and fingervein capture success
		{
			if (m_nEnrollIndex > 0)
			{
				if (ZKFingerVein_Verify(m_hDevice, BIO_TYPE_FV, fvTmp, cbFVTmp, m_preRegFVTmps[m_nEnrollIndex-1], m_nPreRegFVTmpSize[m_nEnrollIndex-1]) <= 0)
				{
					//SetDlgItemText(IDC_EDIT_REPORT, _T("Enroll failed!"));
					DebugLog(CString("Enroll failed!"));
					m_bRegister = FALSE;
					m_nEnrollIndex = 0;
				}
			}
			memcpy(m_regFvImage[m_nEnrollIndex],fvImg,fvImgSize);
			m_nregFvImageSize[m_nEnrollIndex] = fvImgSize;
			memcpy(m_preRegFVTmps[m_nEnrollIndex], fvTmp, cbFVTmp);
			m_nPreRegFVTmpSize[m_nEnrollIndex] = cbFVTmp;
			m_nEnrollIndex++;
			if (m_nEnrollIndex >= 3)
			{
				int ret = 0; 
				size_t len = wcslen(m_strFingerID.GetBuffer()) + 1;
				size_t converted = 0;
				char *CStr;
				CStr=(char*)malloc(len*sizeof(char));
				wcstombs_s(&converted,CStr,len,m_strFingerID.GetBuffer(),_TRUNCATE);
				if (ZKFV_ERR_OK == (ret = ZKFingerVein_DBAdd(m_hDBCache, BIO_TYPE_FV, CStr, m_preRegFVTmps, ENROLL_CNT)))
				{
					DebugLog(CString("Enroll succ!"));
					/*m_NowImage_FP=NULL;
					m_NowImage_FV=new unsigned char[m_imgFVWidth * m_imgFVHeight];
					memcpy(m_NowImage_FV,fvImg,fvImgSize);*/
					//save Last register featue, to verify sample
					for (int i=0;i<ENROLL_CNT;i++)
					{
						m_nlastRegFVTmpSize[i] = m_nPreRegFVTmpSize[i];		
						memcpy(m_lastRegFVTmps[i], m_preRegFVTmps[i], m_nPreRegFVTmpSize[i]);
					}
				}
				else
				{
					CString strLog;
					strLog.Format(_T("ZKFingerVein_DBAdd failed, ret=%d\r\n"), ret);
					DebugLog(strLog);
					//SetDlgItemText(IDC_EDIT_REPORT, strLog);
				}
				m_bRegister = FALSE;
				m_nEnrollIndex = 0;
			}
			else
			{
				CString strLog;
				strLog.Format(_T("You need press your finger %d times\r\n"), ENROLL_CNT-m_nEnrollIndex);
				DebugLog(strLog);
				//SetDlgItemText(IDC_EDIT_REPORT, strLog);
			}
		}

}

void CZKFPDemo3Dlg::FP_Register(unsigned char* fpTmp, int cbFPTmp, unsigned char* fvTmp, int cbFVTmp,unsigned char * fpImg,int fpImgSize, unsigned char * fvImg,int fvImgSize)
{
	if (cbFPTmp > 0)	//fingerprint and fingervein capture success
		{
			if (m_nEnrollIndex > 0)
			{
				if (ZKFingerVein_Verify(m_hDevice, BIO_TYPE_FP, fpTmp, cbFPTmp, m_preRegFPTmps[m_nEnrollIndex-1], m_nPreRegFPTmpSize[m_nEnrollIndex-1]) <= 0)
				{
					//SetDlgItemText(IDC_EDIT_REPORT, _T("Enroll failed!"));
					DebugLog(CString("Enroll failed!"));
					m_bRegister = FALSE;
					m_nEnrollIndex = 0;
				}
			}
			memcpy(m_regFpImage[m_nEnrollIndex],fpImg,fpImgSize);
			m_nregFpImageSize[m_nEnrollIndex] = fpImgSize;
			memcpy(m_preRegFPTmps[m_nEnrollIndex], fpTmp, cbFPTmp);
			m_nPreRegFPTmpSize[m_nEnrollIndex] = cbFPTmp;
			m_nEnrollIndex++;
			if (m_nEnrollIndex >= 3)
			{
				int ret = 0; 
				size_t len = wcslen(m_strFingerID.GetBuffer()) + 1;
				size_t converted = 0;
				char *CStr;
				CStr=(char*)malloc(len*sizeof(char));
				wcstombs_s(&converted,CStr,len,m_strFingerID.GetBuffer(),_TRUNCATE);
				if (ZKFV_ERR_OK == (ret = ZKFingerVein_DBAdd(m_hDBCache, BIO_TYPE_FP, CStr , m_preRegFPTmps, ENROLL_CNT)))
				{
					//SetDlgItemText(IDC_EDIT_REPORT, _T("Enroll succ!"));
					DebugLog(CString("Enroll succ!"));
					/*m_NowImage_FP=new unsigned char[m_imgFPWidth * m_imgFPHeight];
					m_NowImage_FV=NULL;
					memcpy(m_NowImage_FP,fpImg,fpImgSize);*/
					//save Last register featue, to verify sample
					for (int i=0;i<ENROLL_CNT;i++)
					{
						m_nlastRegFPTmpSize[i] = m_nPreRegFPTmpSize[i];
						memcpy(m_lastRegFPTmps[i], m_preRegFPTmps[i], m_nPreRegFPTmpSize[i]);
					}
				}
				else
				{
					CString strLog;
					strLog.Format(_T("ZKFingerVein_DBAdd failed, ret=%d\r\n"), ret);
					DebugLog(strLog);
					//SetDlgItemText(IDC_EDIT_REPORT, strLog);
				}
				m_bRegister = FALSE;
				m_nEnrollIndex = 0;
			}
			else
			{
				CString strLog;
				strLog.Format(_T("You need press your finger %d times\r\n"), ENROLL_CNT-m_nEnrollIndex);
				DebugLog(strLog);
				//SetDlgItemText(IDC_EDIT_REPORT, strLog);
			}
		}

}

void CZKFPDemo3Dlg::DoRegister(unsigned char* fpTmp, int cbFPTmp, unsigned char* fvTmp, int cbFVTmp,unsigned char * fpImg,int fpImgSize, unsigned char * fvImg,int fvImgSize)
{
	int identifyMode = GetIdentifyMode(2);
	if(identifyMode==2) //mixing
	{
		HY_Register(fpTmp,cbFPTmp, fvTmp,cbFVTmp,fpImg, fpImgSize, fvImg, fvImgSize);
	}
	else if(identifyMode==1)//FV
	{
		FV_Register(fpTmp,cbFPTmp, fvTmp,cbFVTmp,fpImg, fpImgSize, fvImg, fvImgSize);
	}
	else  //FP
	{
		FP_Register(fpTmp,cbFPTmp, fvTmp,cbFVTmp,fpImg, fpImgSize, fvImg, fvImgSize);
	}

}


void CZKFPDemo3Dlg::DoVerify(unsigned char* fpTmp, int cbFPTmp, unsigned char* fvTmp, int cbFVTmp)
{
	if (m_bIdentify)
	{
		int identifyMode = GetIdentifyMode(1);

		char szFingerID[128] = {0x0};
		CString strLog;
		int score = 0;
		int ret = 0;
		if (0 == identifyMode)
		{
			if (cbFPTmp > 0 && cbFVTmp > 0)
			{
				if (ZKFV_ERR_OK == (ret = ZKFingerVein_DBHybridIdentify(m_hDBCache, IDENTIFY_MODE_ANY, fpTmp, cbFPTmp, fvTmp, cbFVTmp, szFingerID, &score)))
				{		
					strLog.Format(_T("Normal-Hybrid identify succ, tid=%s, score=%d"), szFingerID, score);
					DebugLog(strLog);
					//SetDlgItemText(IDC_EDIT_REPORT, strLog);
				}
				else
				{
					strLog.Format(_T("Normal-Hybrid identify fail, ret=%d"), ret);
					DebugLog(strLog);
					//SetDlgItemText(IDC_EDIT_REPORT, strLog);
				}
			}
			else
			{
				DebugLog(CString("Hybrid-Identify need capture fingerprint and fingervein succ!"));
				//SetDlgItemText(IDC_EDIT_REPORT, _T("Hybrid-Identify need capture fingerprint and fingervein succ!"));
			}
		}
		else if (1 == identifyMode)
		{
			if (cbFPTmp > 0 && cbFVTmp > 0)
			{
				if (ZKFV_ERR_OK == (ret = ZKFingerVein_DBHybridIdentify(m_hDBCache, IDENTIFY_MODE_FAKE, fpTmp, cbFPTmp, fvTmp, cbFVTmp, szFingerID, &score)))
				{		
					strLog.Format(_T("Fake-Hybrid identify succ, tid=%s, score=%d"), szFingerID, score);
					DebugLog(strLog);
					//SetDlgItemText(IDC_EDIT_REPORT, strLog);
				}
				else
				{
					strLog.Format(_T("Fake-Hybrid identify fail, ret=%d"), ret);
					DebugLog(strLog);
					//SetDlgItemText(IDC_EDIT_REPORT, strLog);
				}
			}
			else
			{
				DebugLog(CString("Hybrid-Identify need capture fingerprint and fingervein succ!"));
				//SetDlgItemText(IDC_EDIT_REPORT, _T("Hybrid-Identify need capture fingerprint and fingervein succ!"));
			}
		}
		else if(2 == identifyMode)
		{
			if (cbFPTmp > 0 && cbFVTmp > 0)
			{
				if (ZKFV_ERR_OK == (ret = ZKFingerVein_DBHybridIdentify(m_hDBCache, IDENTIFY_MODE_BOTH, fpTmp, cbFPTmp, fvTmp, cbFVTmp, szFingerID, &score)))
				{		
					strLog.Format(_T("Security-Hybrid identify succ, tid=%s, score=%d"), szFingerID, score);
					DebugLog(strLog);
					//SetDlgItemText(IDC_EDIT_REPORT, strLog);
				}
				else
				{
					strLog.Format(_T("Security-Hybrid identify fail, ret=%d"), ret);
					DebugLog(strLog);
					//SetDlgItemText(IDC_EDIT_REPORT, strLog);
				}
			}
			else
			{
				DebugLog(CString("Hybrid-Identify need capture fingerprint and fingervein succ!"));
				//SetDlgItemText(IDC_EDIT_REPORT, _T("Hybrid-Identify need capture fingerprint and fingervein succ!"));
			}
		}
		else
		{
			strLog = _T("");
			if (cbFPTmp > 0 && ZKFV_ERR_OK == (ret = ZKFingerVein_DBIdentify(m_hDBCache, BIO_TYPE_FP, fpTmp, cbFPTmp, szFingerID, &score)))
			{
				CString strTmp;
				strTmp.Format(_T("Identify fingerprint success, tid=%s, score=%d\r\n"), szFingerID, score);
				strLog += strTmp;
			}
			if (cbFVTmp > 0 && ZKFV_ERR_OK == (ret = ZKFingerVein_DBIdentify(m_hDBCache, BIO_TYPE_FV, fvTmp, cbFVTmp, szFingerID, &score)))
			{
				CString strTmp;
				strTmp.Format(_T("Identify finger-vein success, tid=%s, score=%d\r\n"), szFingerID, score);
				strLog += strTmp;
			}
			if (strLog.IsEmpty())
			{
				DebugLog(CString("Identify failed"));
				//SetDlgItemText(IDC_EDIT_REPORT, _T("Identify failed"));
			}
			else
			{
				DebugLog(strLog);
				//SetDlgItemText(IDC_EDIT_REPORT, strLog);
			}
		}
	}
	else
	{
		if (m_nlastRegFVTmpSize[0] <= 0&&m_nlastRegFPTmpSize[0]<=0)
		{
			DebugLog(CString("no fingervein registered"));
			//SetDlgItemText(IDC_EDIT_REPORT, _T("no fingervein registered"));
			return;
		}
		CString strLog;
		if (cbFPTmp > 0)
		{
			CString strTmp = _T("Verify fingerprint failed!\r\n");
			int score = 0;
			for (int i = 0;i<ENROLL_CNT;i++)
			{
				if ((score = ZKFingerVein_Verify(m_hDevice, BIO_TYPE_FP, m_lastRegFPTmps[i], m_nlastRegFPTmpSize[i], fpTmp, cbFPTmp)) > 0)
				{
					strTmp.Format(_T("Verify fingerprint succ, score=%d!\r\n"), score);
					break;
				}
			}
			strLog += strTmp;
		}
		if (cbFVTmp > 0)
		{
			CString strTmp = _T("Verify fingervein failed!\r\n");
			int score = 0;
			for (int i = 0;i<ENROLL_CNT;i++)
			{
				if ((score = ZKFingerVein_Verify(m_hDevice, BIO_TYPE_FV, m_lastRegFVTmps[i], m_nlastRegFVTmpSize[i], fvTmp, cbFVTmp)) > 0)
				{
					strTmp.Format(_T("Verify fingervein succ, score=%d!\r\n"), score);
					break;
				}
			}
			strLog += strTmp;
		}
		DebugLog(strLog);
		//SetDlgItemText(IDC_EDIT_REPORT, strLog);
	}
}

void CZKFPDemo3Dlg::DebugLog(CString &CS)
{
	EditData+=CS;
	EditData+="\r\n";
	SetDlgItemText(IDC_EDIT_REPORT,EditData);
}




DWORD WINAPI CZKFPDemo3Dlg::ThreadCapture(LPVOID lParam)
{
	CZKFPDemo3Dlg* pDlg = (CZKFPDemo3Dlg*)lParam;
	if (NULL != pDlg)
	{
		pDlg->m_bStopThread = FALSE;
		unsigned char* pBufFPImage = new unsigned char[pDlg->m_imgFPWidth*pDlg->m_imgFPHeight];
		int nFPImageSize = 0;
		unsigned char* pBufFVImage = new unsigned char[pDlg->m_imgFVWidth*pDlg->m_imgFVHeight];
		int nFVImageSize = 0;
		unsigned char szFPTmp[MAX_TEMPLATE_SIZE] = {0x0};
		int nFPTmpSize = 0;
		unsigned char szFVTmp[MAX_TEMPLATE_SIZE] = {0x0};
		int nFVTmpSize = 0;
		while(!pDlg->m_bStopThread)
		{
			nFPImageSize = pDlg->m_imgFPWidth*pDlg->m_imgFPHeight;
			nFVImageSize = pDlg->m_imgFVWidth*pDlg->m_imgFVHeight;
			nFPTmpSize = MAX_TEMPLATE_SIZE;
			nFVTmpSize = MAX_TEMPLATE_SIZE;
			memset(szFPTmp, 0x0, MAX_TEMPLATE_SIZE);
			memset(szFVTmp, 0x0, MAX_TEMPLATE_SIZE);
			int ret = ZKFingerVein_CaptureFingerVeinImageAndTemplate(pDlg->m_hDevice, 
				pBufFPImage, &nFPImageSize, pBufFVImage, &nFVImageSize,
				szFPTmp, &nFPTmpSize, szFVTmp, &nFVTmpSize);
			if (ZKFV_ERR_OK == ret)
			{
				if(nFPTmpSize>0||nFVTmpSize>0)
				{
					CBase64Coder *Code2Base=new CBase64Coder();
					

					if(nFPTmpSize>0&&nFVTmpSize>0)
					{
						const char* OutTemp_FP= Code2Base->encode(szFPTmp,nFPTmpSize);	
						const char* OutTemp_FV= Code2Base->encode(szFVTmp,nFVTmpSize);	
						/*byte2hex(szFPTmp,nFPTmpSize,OutTemp_FP,&Lenth_FP);
						byte2hex(szFVTmp,nFVTmpSize,OutTemp_FV,&Lenth_FV);*/
						/*cs= pDlg->FUN_Char2CString("FP Template: ", (char *)OutTemp_FP);
						cs1=pDlg->FUN_Char2CString("FV Template: ", (char *)OutTemp_FV);	*/
						
						CString cs(OutTemp_FP);
						cs.Replace(_T("\r\n"),_T(" "));
					
						CString cs1(OutTemp_FV);	
						cs1.Replace(_T("\r\n"),_T(" "));

						pDlg->DebugLog(CString("FP Template:"));
						pDlg->DebugLog(cs);

						pDlg->DebugLog(CString("FV Template:"));
						pDlg->DebugLog(cs1);	

					}
					else if(nFPTmpSize>0)
					{
						const char* OutTemp_FP= Code2Base->encode(szFPTmp,nFPTmpSize);
						CString cs(OutTemp_FP);
						cs.Replace(_T("\r\n"),_T(" "));	

						pDlg->DebugLog(CString("FP Template:"));
						pDlg->DebugLog(cs);
					}
					else
					{		
						const char* OutTemp_FV= Code2Base->encode(szFVTmp,nFVTmpSize);	
						CString cs1(OutTemp_FV);	
						cs1.Replace(_T("\r\n"),_T(" "));

						pDlg->DebugLog(CString("FV Template:"));
						pDlg->DebugLog(cs1);
					}
				}
				if(nFPImageSize>0&&nFVImageSize>0)
				{
					pDlg->m_NowImage_FP=new unsigned char[pDlg->m_imgFPWidth * pDlg->m_imgFPHeight];
					pDlg->m_NowImage_FV=new unsigned char[pDlg->m_imgFVWidth * pDlg->m_imgFVHeight];
					memcpy(pDlg->m_NowImage_FP,pBufFPImage,nFPImageSize);
					memcpy(pDlg->m_NowImage_FV,pBufFVImage,nFVImageSize);
				}
				if(nFPImageSize>0&&nFVImageSize<=0)
				{
					pDlg->m_NowImage_FP=new unsigned char[pDlg->m_imgFPWidth * pDlg->m_imgFPHeight];
					pDlg->m_NowImage_FV=NULL;
					memcpy(pDlg->m_NowImage_FP,pBufFPImage,nFPImageSize);
				}
				if(nFVImageSize>0&&nFPImageSize<=0)
				{	
					pDlg->m_NowImage_FP=NULL;
					pDlg->m_NowImage_FV=new unsigned char[pDlg->m_imgFVWidth * pDlg->m_imgFVHeight];
					memcpy(pDlg->m_NowImage_FV,pBufFVImage,nFVImageSize);
				}
			

				if (nFPImageSize > 0)
				{
					pDlg->SendMessage(WM_FINGER_RECEIVED, (WPARAM)pBufFPImage, (LPARAM)nFPImageSize);
				}
				if (nFVImageSize > 0)
				{
					pDlg->SendMessage(WM_VEIN_RECEIVED, (WPARAM)pBufFVImage, (LPARAM)nFVImageSize);
				}
				if (pDlg->m_bRegister)
				{
					pDlg->DoRegister(szFPTmp, nFPTmpSize, szFVTmp, nFVTmpSize, pBufFPImage, nFPImageSize, pBufFVImage, nFVImageSize);
				}
				else
				{
					pDlg->DoVerify(szFPTmp, nFPTmpSize, szFVTmp, nFVTmpSize);
				}
			}
		

			Sleep(100);
		}
	}
	return 0;
}

CString CZKFPDemo3Dlg::FUN_Char2CString(char *ch1, char * ch2)  //ch1 For additional instructions
{
	CString cs;
	USES_CONVERSION;
	TCHAR* pUnicode1 = A2T(ch1);
	TCHAR* pUnicode2 = A2T(ch2);
	if (pUnicode1 == NULL)
	{
		cs.Format(_T("%s"), pUnicode2);
	}
	else
	{
		cs.Format(_T("%s  %s"), pUnicode1, pUnicode2);
	}

	return cs;
}

void CZKFPDemo3Dlg::OnBnClickedBtnConn()
{

	//SetDlgItemText(IDC_EDIT_REPORT, _T("Start Conect"));
	// TODO: Add control notification handler code here
	if(NULL==m_hDevice)
	{
		if(ZKFingerVein_Init()!=ZKFV_ERR_OK)
		{
			DebugLog(CString("Init ZKFVM fail"));
			//SetDlgItemText(IDC_EDIT_REPORT,_T("Init ZKFVM fail"));
			return ;
		}
		if((m_hDevice=ZKFingerVein_OpenDevice(0))==NULL)
		{
			//SetDlgItemText(IDC_EDIT_REPORT,_T("Open Sensor fail"));
			DebugLog(CString("Open Sensor Fail"));
			ZKFingerVein_Terminate();
			return ;
		}
		m_hDBCache=ZKFingerVein_DBInit(m_hDevice);
		if(NULL==m_hDBCache)
		{
			//SetDlgItemText(IDC_EDIT_REPORT,_T("Create DBCache fail"));
			DebugLog(CString("Create DBCache fail"));
			ZKFingerVein_CloseDevice(m_hDevice);
			ZKFingerVein_Terminate();
			return ;
		}

		int nFullWidth = 0;
		int nFullHeight = 0;
		int retSize = sizeof(int);
		ZKFingerVein_GetParameter(m_hDevice, 1, (unsigned char*)&nFullWidth, &retSize);
		retSize = sizeof(int);
		ZKFingerVein_GetParameter(m_hDevice, 2, (unsigned char*)&nFullHeight, &retSize);
		
		m_preRegFPTmps=new unsigned char*[ENROLL_CNT];
		m_preRegFVTmps=new unsigned char*[ENROLL_CNT];
		m_regFpImage=new unsigned char*[ENROLL_CNT];
		m_regFvImage=new unsigned char*[ENROLL_CNT];
		m_lastRegFPTmps=new unsigned char*[ENROLL_CNT];
		m_lastRegFVTmps=new unsigned char*[ENROLL_CNT];
		

		m_imgFPWidth = nFullWidth&0xFFFF;
		m_imgFPHeight = nFullHeight&0xFFFF;
		m_imgFVWidth = (nFullWidth >> 16) & 0xFFFF;
		m_imgFVHeight = (nFullHeight >> 16) & 0xFFFF;
	
		for (int i=0;i<ENROLL_CNT;i++)
		{
			m_preRegFPTmps[i] = new unsigned char[MAX_TEMPLATE_SIZE];
			m_preRegFVTmps[i] = new unsigned char[MAX_TEMPLATE_SIZE];
			m_lastRegFPTmps[i] = new unsigned char[MAX_TEMPLATE_SIZE];
			m_lastRegFVTmps[i] = new unsigned char[MAX_TEMPLATE_SIZE];
			m_regFpImage[i] = new unsigned char[m_imgFPWidth * m_imgFPHeight];
			m_regFvImage[i] = new unsigned char[m_imgFVWidth * m_imgFVHeight];
		}

		/*m_NowImage_FP=new unsigned char[m_imgFPWidth * m_imgFPHeight];
		m_NowImage_FV=new unsigned char[m_imgFVWidth * m_imgFVHeight];*/

		memset(m_nPreRegFPTmpSize, 0x0, ENROLL_CNT*sizeof(int));
		memset(m_nPreRegFVTmpSize, 0x0, ENROLL_CNT*sizeof(int));
		memset(m_nlastRegFPTmpSize, 0x0, ENROLL_CNT*sizeof(int));
		memset(m_nlastRegFVTmpSize, 0x0, ENROLL_CNT*sizeof(int));
		memset(m_nregFpImageSize, 0x0, ENROLL_CNT*sizeof(int));
		memset(m_nregFvImageSize, 0x0, ENROLL_CNT*sizeof(int));

		m_nEnrollIndex = 0;

		m_bnConn.EnableWindow(false);
		m_bnDisConn.EnableWindow(true);
		m_bnEnroll.EnableWindow(true);
		m_bnVerify.EnableWindow(true);
		m_bnIdentify.EnableWindow(true);
		m_bnClear.EnableWindow(true);
		//m_bnTest.EnableWindow(true);
		
		m_hThreadWork = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadCapture, this, 0, NULL);

		//SetDlgItemText(IDC_EDIT_REPORT, _T("Init Succ"));
		DebugLog(CString("Init Succ"));
		m_strFingerID.Empty();

		//Display SDK version number
		char cVerion[10] = {0x0};
		//CString CS;
		int leng = 10;
		if(ZKFingerVein_GetSDKVersion(cVerion,&leng) == ZKFV_ERR_OK)
		{
			DebugLog(FUN_Char2CString("Init Succ��Version is ", cVerion));
			//SetDlgItemText(IDC_EDIT_REPORT, FUN_Char2CString("Init Succ��Version is ", cVerion));
		}
	

	}
	else
	{
		//SetDlgItemText(IDC_EDIT_REPORT,_T("Already Init"));
		DebugLog(CString("Already Init"));
	}
	return;
}


void RotateImage(BYTE *ptr, int *width, int *height, int degree)
{
	int i, j, k, w, h;
	BYTE *tmp = NULL;
	w = *width;
	h = *height;
	tmp = (BYTE *)malloc(sizeof(BYTE)*(w * h));
	//BYTE *tmp = new BYTE[w * h];

	//char *tmp = (char *)malloc(sizeof(char)*(w * h));

	if (degree == -90)	//anticlockwise 
	{
		for(i=0;i<w;i++)
		{
			for(j=0;j<h;j++)
			{
				tmp[i*h+j]=ptr[(w-i)*h+(h-j)];
			}
		}
	}
	else				//clockwise 
	{
		for (i = 0; i < h; i++)
		{
			k = (h - i - 1);
			for (j = 0; j < w; j++)
			{
				tmp[h * j + k] = ptr[w * i + j];
			}
		}
	}
	memcpy(ptr, tmp, w * h);
	*width = h;
	*height = w;
	if (NULL != tmp)
	{
		free (tmp);
		tmp = NULL;
	}

	//delete[]tmp;
}



LRESULT CZKFPDemo3Dlg::OnMsgFingerReceived(WPARAM wParam, LPARAM lParam)
{
	BYTE* pShowImg = new BYTE[640*480];
	ConvertImage((BYTE*)wParam, pShowImg, m_imgFPWidth, m_imgFPHeight, 240, 300, 0);
	HBITMAP hBitmap = BuildImage(pShowImg, 240, 300);
	delete [] pShowImg;
	m_cPicFingerPrint.SetBitmap(hBitmap);
	return S_OK;
}

LRESULT CZKFPDemo3Dlg::OnMsgVeinReceived(WPARAM wParam, LPARAM lParam)
{
	BYTE* pSrc = new BYTE[640*480];
	BYTE* pShowImg = new BYTE[640*480];
	rotate90((BYTE*)wParam, pSrc, m_imgFVWidth, m_imgFVHeight);
	ConvertImage(pSrc, pShowImg, m_imgFVHeight, m_imgFVWidth, 240, 300, 1);
	RotateImage(pShowImg, &m_imgFVWidth, &m_imgFVHeight, 0);
	RotateImage(pShowImg, &m_imgFVWidth, &m_imgFVHeight, 0);
	HBITMAP hBitmap = BuildImage(pShowImg, 240, 300);
	delete [] pShowImg;
	delete [] pSrc;
	m_cPicFingerVien.SetBitmap(hBitmap);
	//m_cPicFingerPrint.SetBitmap(hBitmap);
	return S_OK;
}


void CZKFPDemo3Dlg::OnCbnSelchangeCombo1()
{
	// TODO: Add control notification handler code here
}

void CZKFPDemo3Dlg::OnEnChangeEdit1()
{
	// TODO:  If the control is a RICHEDIT control,
      // it will not send this notification unless the 
      //CDialog::OnInitDialog() function is overridden and CRichEditCtrl().SetEventMask() is called, 
      //and the ENM_CHANGE flag is ORed into the mask.

	// TODO:  Add control notification handler code here
}



void CZKFPDemo3Dlg::OnBnClickedBtnDisconn()
{
	// TODO: Add control notification handler code here
	//SetDlgItemText(IDC_EDIT_REPORT, _T("ready for DisConect"));
	if (NULL != m_hDevice)
		{
			m_bStopThread = TRUE;
			if (NULL != m_hThreadWork)
			{
				
				WaitForSingleObject(m_hThreadWork, INFINITE);
				CloseHandle(m_hThreadWork);
				m_hThreadWork = NULL;
			}
			if (NULL != m_hDBCache)
			{
				ZKFingerVein_DBFree(m_hDBCache);
				m_hDBCache = NULL;
			}
			ZKFingerVein_CloseDevice(m_hDevice);
			ZKFingerVein_Terminate();
			m_hDevice = NULL;
			//SetDlgItemText(IDC_EDIT_REPORT, _T("Close Succ"));
			DebugLog(CString("Close Succ"));
			m_bnConn.EnableWindow(true);
			m_bnDisConn.EnableWindow(false);
			m_bnEnroll.EnableWindow(false);
			m_bnVerify.EnableWindow(false);
			m_bnIdentify.EnableWindow(false);
			m_bnClear.EnableWindow(false);

			if (NULL != m_preRegFPTmps)
			{
				for (int i=0;i<ENROLL_CNT;i++)
				{
					delete[] m_preRegFPTmps[i];
				}
				delete[] m_preRegFPTmps;
				m_preRegFPTmps = NULL;
			}

			if (NULL != m_preRegFVTmps)
			{
				for (int i=0;i<ENROLL_CNT;i++)
				{
					delete[] m_preRegFVTmps[i];
				}
				delete[] m_preRegFVTmps;
				m_preRegFVTmps = NULL;
			}

			if (NULL != m_regFpImage)
			{
				for (int i=0;i<ENROLL_CNT;i++)
				{
					delete[] m_regFpImage[i];
				}
				delete[] m_regFpImage;
				m_regFpImage = NULL;
			}

			if (NULL != m_regFvImage)
			{
				for (int i=0;i<ENROLL_CNT;i++)
				{
					delete[] m_regFvImage[i];
				}
				delete[] m_regFvImage;
				m_regFvImage = NULL;
			}

			if (NULL == m_lastRegFVTmps)
			{
				for (int i=0;i<ENROLL_CNT;i++)
				{
					delete[] m_lastRegFVTmps[i];
				}
				delete[] m_lastRegFVTmps;
				m_lastRegFVTmps = NULL;
			}

			if (NULL == m_lastRegFPTmps)
			{
				for (int i=0;i<ENROLL_CNT;i++)
				{
					delete[] m_lastRegFPTmps[i];
				}
				delete[] m_lastRegFPTmps;
				m_lastRegFPTmps = NULL;
			}
		}
		return ;
}




void CZKFPDemo3Dlg::OnBnClickedBtnEnroll()
{
	//SetDlgItemText(IDC_EDIT_REPORT, _T("Start  Enroll"));
	// TODO: Add control notification handler code here
	if (NULL != m_hDevice)
	{
		CString strTemp;
		GetDlgItemText(IDC_EDIT_USERID, strTemp);
		if (strTemp.IsEmpty())
		{
			//SetDlgItemText(IDC_EDIT_REPORT, _T("Please input a correct user id!"));
			DebugLog(CString("Please input a correct user id"));
			return ;
		}
		m_strFingerID = strTemp;
		if (!m_bRegister)
		{
			m_bRegister = TRUE;
			m_nEnrollIndex = 0;
			//SetDlgItemText(IDC_EDIT_REPORT, _T("Doing register, please press your finger 3 times!"));
			DebugLog(CString("Doing Rgister ,please press your finger 3 times"));
		}
	}
	return ;
}

void CZKFPDemo3Dlg::OnBnClickedBtnVerify()
{
	//	SetDlgItemText(IDC_EDIT_REPORT, _T("Start  Verify"));
	// TODO: Add control notification handler code here
	if (NULL != m_hDevice)
	{
		if (m_bRegister)
		{
			m_bRegister = FALSE;
			//SetDlgItemText(IDC_EDIT_REPORT, _T("Start verify last register template"));
			DebugLog(CString("Start verify last register template"));
		}
		m_bIdentify = FALSE;
	}
	return ;
}

void CZKFPDemo3Dlg::OnBnClickedBtnIdentify()
{
	//SetDlgItemText(IDC_EDIT_REPORT, _T("Start  Identity"));
	// TODO: Add control notification handler code here
	if (NULL != m_hDevice)
	{
		if (m_bRegister)
		{
			m_bRegister = FALSE;
			//SetDlgItemText(IDC_EDIT_REPORT, _T("Please input your finger"));
			DebugLog(CString("Please input your finger"));
		}
		m_bIdentify = TRUE;
	}
	return ;
}

void CZKFPDemo3Dlg::OnBnClickedBtnClear()
{
	//SetDlgItemText(IDC_EDIT_REPORT, _T("Start  Clear"));
	// TODO: Add control notification handler code here
	if (NULL != m_hDevice)
	{
		ZKFingerVein_DBClear(m_hDBCache, BIO_TYPE_FP);
		ZKFingerVein_DBClear(m_hDBCache, BIO_TYPE_FV);
		//SetDlgItemText(IDC_EDIT_REPORT, _T("Clear Finished"));
		DebugLog(CString("Clear Finished"));
	}
	else
	{
		//SetDlgItemText(IDC_EDIT_REPORT, _T("Please connect device first"));
		DebugLog(CString("Please connect device first"));
	}
	return ;
}

void CZKFPDemo3Dlg::OnBnClickedBtnTest()
{

}

void CZKFPDemo3Dlg::OnBnClickedButton1()
{
	// TODO: Add control notification handler code here
		// TODO: Add control notification handler code here
	CString strLog;
	m_bRegister = false;

	if(m_hDevice == NULL)
	{
		//SetDlgItemText(IDC_EDIT_REPORT, _T("Please connect the device"));
		DebugLog(CString("Please connect the device"));
		return ;
	}
	//show serial number
	int flag = 1103; 
	unsigned char DevSN[64] = {0x0};
	int size = 64;
	ZKFingerVein_GetParameter(m_hDevice,1103,DevSN,&size);

	//show device name
	flag = 1102; 
	unsigned char DevMame[64] = {0x0};
	size = 64;
	ZKFingerVein_GetParameter(m_hDevice,1102,DevMame,&size);


	//show firmware version
	flag = 1201; 
	unsigned char FwVersion[3] = {0x0};
	size = 3;
	ZKFingerVein_GetParameter(m_hDevice,1201,FwVersion,&size);	
	strLog+=FUN_Char2CString(" DevName = ",(char *)DevMame);
	strLog+=',';
	strLog+=FUN_Char2CString(" SN = ",(char *)DevSN);
	strLog+=',';
	CString CS;
	CS.Format(_T(" FwVersion = %d.%d"),FwVersion[1],FwVersion[0]);
	strLog+=CS;
	DebugLog(strLog);
	return ;
}

void CZKFPDemo3Dlg::OnBnClickedButton2()
{
	// TODO: Add control notification handler code here
	EditData.Empty();
	SetDlgItemText(IDC_EDIT_REPORT,EditData);
}


void CZKFPDemo3Dlg::OnBnClickedButton3()
{
	CString strTemp;
	GetDlgItemText(IDC_EDIT_USERID, strTemp);
	if(strTemp.IsEmpty())
	{
		DebugLog(CString("Please input a correct user id"));
		return;
	}
	m_strFingerID=strTemp;
	// TODO: Add control notification handler code here
	int ret = 0; 
	size_t len = wcslen(m_strFingerID.GetBuffer(m_strFingerID.GetLength())) + 1;
	size_t converted = 0;
	char *pUsrID ;	
	pUsrID=(char*)malloc(len*sizeof(char));
	wcstombs_s(&converted,pUsrID,len,m_strFingerID.GetBuffer(m_strFingerID.GetLength()),_TRUNCATE);
	char strFpFileName[64] = {0x0};
	char strFvFileName[64] = {0x0};
	if(NULL!=m_NowImage_FV&&NULL!=m_NowImage_FP)
	{
		sprintf(strFpFileName,"userId%s_fp.bmp",pUsrID);
		WriteBitmap(m_NowImage_FP,m_imgFPWidth,m_imgFPHeight,strFpFileName);
		sprintf(strFvFileName,"userId%s_fv.bmp",pUsrID);
		WriteBitmap(m_NowImage_FV,m_imgFVWidth,m_imgFVHeight,strFvFileName);
		DebugLog(CString("Put Out Fp/Fv_Pic Suc"));
	}
	else if(NULL!=m_NowImage_FV)
	{
		sprintf(strFvFileName,"userId%s_fv.bmp",pUsrID);
		WriteBitmap(m_NowImage_FV,m_imgFVWidth,m_imgFVHeight,strFvFileName);
		DebugLog(CString("Put Out Fv_Pic Suc"));
	}
	else if(NULL!=m_NowImage_FP)
	{
		sprintf(strFpFileName,"userId%s_fp.bmp",pUsrID);
		WriteBitmap(m_NowImage_FP,m_imgFPWidth,m_imgFPHeight,strFpFileName);
		DebugLog(CString("Put Out Fp_Pic Suc"));
	}
	else 
	{
		DebugLog(CString("NO Pic Resource"));
	}
	return;
}

void CZKFPDemo3Dlg::OnBnClickedButton5()
{
	// TODO: Add control notification handler code here
}

void CZKFPDemo3Dlg::OnBnClickedButton6()
{
	//1:1 fp
	// TODO: Add control notification handler code here
	if(m_hDevice==NULL)
	{
		DebugLog(CString("Please connect Device"));
		return;
	}
	CString CS;
	GetDlgItemText(IDC_EDIT2,CS);
	if(CS.IsEmpty()||_ttoi(CS)>100||_ttoi(CS)<0)
	{
		DebugLog(CString("Please input thredwold data at 0-100"));
		return;
	}
	int ret=0;
	if((ret=ZKFingerVein_SetThreshold(m_hDBCache,1,_ttoi(CS)))==0)
	{
		CString PutOut;
		int value=0;
		ret= ZKFingerVein_GetThreshold(m_hDBCache,1,&value);
		PutOut.Format(_T("(reference value:35)  Set  thredshold:%d  "),value);
		DebugLog(PutOut);
	}

}

void CZKFPDemo3Dlg::OnBnClickedButton7()
{
	// TODO: Add control notification handler code here
	if(m_hDevice==NULL)
	{
		DebugLog(CString("Please connect Device"));
		return;
	}

	CString CS;
	GetDlgItemText(IDC_EDIT3,CS);
	if(CS.IsEmpty()||_ttoi(CS)>100||_ttoi(CS)<0)
	{
		DebugLog(CString("Please input thredwold data at 0-100"));
		return;
	}
	int ret=0;
	if((ret=ZKFingerVein_SetThreshold(m_hDBCache,2,_ttoi(CS)))==0)
	{
		CString PutOut;
		int value=0;
		ret= ZKFingerVein_GetThreshold(m_hDBCache,2,&value);
		PutOut.Format(_T("(reference value:55)  Set  thredshold:%d  "),value);
		DebugLog(PutOut);
	}
}

void CZKFPDemo3Dlg::OnBnClickedButton8()
{
	// TODO: Add control notification handler code here
	if(m_hDevice==NULL)
	{
		DebugLog(CString("Please connect Device"));
		return;
	}
	CString CS;
	GetDlgItemText(IDC_EDIT4,CS);
	if(CS.IsEmpty()||_ttoi(CS)>100||_ttoi(CS)<0)
	{
		DebugLog(CString("Please input thredwold data at 0-100"));
		return;
	}
	int ret=0;
	if((ret=ZKFingerVein_SetThreshold(m_hDBCache,3,_ttoi(CS)))==0)
	{
		CString PutOut;
		int value=0;
		ret= ZKFingerVein_GetThreshold(m_hDBCache,3,&value);
		PutOut.Format(_T("(reference value:72)  Set  thredshold:%d  "),value);
		DebugLog(PutOut);
	}
}

void CZKFPDemo3Dlg::OnBnClickedButton9()
{
	// TODO: Add control notification handler code here
	if(m_hDevice==NULL)
	{
		DebugLog(CString("Please connect Device"));
		return;
	}
	CString CS;
	GetDlgItemText(IDC_EDIT5,CS);
	if(CS.IsEmpty()||_ttoi(CS)>100||_ttoi(CS)<0)
	{
		DebugLog(CString("Please input thredwold data at 0-100"));
		return;
	}
	int ret=0;
	if((ret=ZKFingerVein_SetThreshold(m_hDBCache,4,_ttoi(CS)))==0)
	{
		CString PutOut;
		int value=0;
		ret= ZKFingerVein_GetThreshold(m_hDBCache,4,&value);
		PutOut.Format(_T("(reference value:82)  Set  thredshold:%d  "),value);
		DebugLog(PutOut);
	}
}
