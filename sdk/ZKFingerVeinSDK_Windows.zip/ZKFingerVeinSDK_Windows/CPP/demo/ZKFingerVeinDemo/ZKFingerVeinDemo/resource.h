//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ZKFingerVeinDemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define xBtnPos                         42
#define IDD_ABOUTBOX                    100
#define yBtnSapce                       100
#define IDS_ABOUTBOX                    101
#define IDD_ZKFPDEMO3_DIALOG            102
#define xBtnSpace                       105
#define IDB_PNG1                        130
#define IDB_PNG2                        131
#define IDB_PNG3                        132
#define IDB_PNG4                        133
#define IDB_BITMAP3                     134
#define IDB_PNG5                        135
#define IDB_PNG6                        136
#define IDB_PNG7                        137
#define IDB_PNG8                        138
#define IDB_PNG9                        139
#define IDB_PNG10                       140
#define IDB_PNG11                       141
#define IDB_BITMAP4                     154
#define IDI_ICON1                       162
#define IDD_MAINDLG                     162
#define IDB_BITMAP1                     213
#define IDB_BITMAP2                     215
#define IDB_BITMAP_FV                   215
#define yBtnPos                         464
#define IDC_BTN_CLOSE                   1000
#define IDC_BUTTON2                     1001
#define IDC_BUTTON3                     1002
#define IDC_BUTTON4                     1003
#define IDC_EDIT_USERID                 1003
#define IDC_BUTTON5                     1004
#define IDC_BUTTON6                     1005
#define IDC_BUTTON7                     1006
#define IDC_STATIC_SN                   1007
#define IDC_BUTTON8                     1007
#define IDC_STATIC_DATE                 1008
#define IDC_EDIT2                       1008
#define IDC_STATIC_REPORT               1009
#define IDC_EDIT3                       1009
#define IDC_BTN_CONN                    1010
#define IDC_BTN_IDENTIFY                1011
#define IDC_BTN_DISCONN                 1012
#define IDC_BTN_VERIFY                  1013
#define IDC_BTN_ENROLL                  1014
#define IDC_COMBO1                      1015
#define IDC_STATIC_UID                  1016
#define IDC_COMBO2                      1016
#define IDC_STATIC_IMODE                1017
#define IDC_EDIT4                       1017
#define IDC_EDIT_REPORT                 1018
#define IDC_BTN_ENROLL2                 1019
#define IDC_BTN_CLEAR                   1019
#define IDC_BUTTON1                     1020
#define IDC_BTN_P                       1020
#define IDC_BTN_DEVPARAM                1020
#define IDC_EDIT5                       1021
#define IDC_BUTTON9                     1022
#define IDC_BTN_TEST                    1025
#define IDC_BTN_TEST1                   1026
#define IDC_EDIT1                       1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        163
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
