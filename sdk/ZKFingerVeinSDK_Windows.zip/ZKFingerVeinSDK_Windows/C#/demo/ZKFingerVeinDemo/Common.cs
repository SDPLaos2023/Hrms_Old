﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommonTool
{
    class Common
    {
        public static int ByteToHex(ref byte[] Src, ulong inLen, ref StringBuilder Dest, ref ulong outLen)
        {
            ulong i = 0;
            //const char[] num = new char[] { char.Parse("0123456789ABCDEF") };
            const  String Str = "0123456789ABCDEF";
            //unsigned char *p = output;
            //static const char[] num = "0123456789ABCDEF";
            if (outLen < inLen * 2)
            {
                outLen = inLen * 2;
                return -1;
            }
            for (i = 0; i < inLen; ++i)
            {
                Dest.Insert((int)i, Str[Src[i] >> 4]);
                Dest.Insert((int)(++i), Str[Src[i] >> 4]);
                //Dest[i] = Str[Src[i] >> 4];
                //Dest[i] = Str[Src[i] & 0x0F];
            }
            //*outlen = p - output;
            return 0;
        
        }
        public static bool Empty(byte[] data, int len)
        {
            for (int i = 0; i < len; i++)
            {
                if (data[i] != 0)             
                    return false;                     
            }
                return true;
        }

    }
}
