﻿namespace ZKFVDemo3_CSharp
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Connect = new System.Windows.Forms.Button();
            this.ClearFinger = new System.Windows.Forms.Button();
            this.Identify = new System.Windows.Forms.Button();
            this.Verify = new System.Windows.Forms.Button();
            this.Enroll = new System.Windows.Forms.Button();
            this.Disconnect = new System.Windows.Forms.Button();
            this.Device = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.FingerVein = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.FingerPrint = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Connect
            // 
            this.Connect.Location = new System.Drawing.Point(525, 389);
            this.Connect.Name = "Connect";
            this.Connect.Size = new System.Drawing.Size(87, 23);
            this.Connect.TabIndex = 0;
            this.Connect.Text = "Conncet";
            this.Connect.UseVisualStyleBackColor = true;
            this.Connect.Click += new System.EventHandler(this.button1_Click);
            // 
            // ClearFinger
            // 
            this.ClearFinger.Enabled = false;
            this.ClearFinger.Location = new System.Drawing.Point(618, 511);
            this.ClearFinger.Name = "ClearFinger";
            this.ClearFinger.Size = new System.Drawing.Size(90, 23);
            this.ClearFinger.TabIndex = 1;
            this.ClearFinger.Text = "ClearFinger";
            this.ClearFinger.UseVisualStyleBackColor = true;
            this.ClearFinger.Click += new System.EventHandler(this.ClearFinger_Click);
            // 
            // Identify
            // 
            this.Identify.Enabled = false;
            this.Identify.Location = new System.Drawing.Point(618, 432);
            this.Identify.Name = "Identify";
            this.Identify.Size = new System.Drawing.Size(90, 23);
            this.Identify.TabIndex = 2;
            this.Identify.Text = "1:N identify";
            this.Identify.UseVisualStyleBackColor = true;
            this.Identify.Click += new System.EventHandler(this.Identify_Click);
            // 
            // Verify
            // 
            this.Verify.Enabled = false;
            this.Verify.Location = new System.Drawing.Point(525, 432);
            this.Verify.Name = "Verify";
            this.Verify.Size = new System.Drawing.Size(87, 23);
            this.Verify.TabIndex = 3;
            this.Verify.Text = "1:1Verify";
            this.Verify.UseVisualStyleBackColor = true;
            this.Verify.Click += new System.EventHandler(this.Verify_Click);
            // 
            // Enroll
            // 
            this.Enroll.Enabled = false;
            this.Enroll.Location = new System.Drawing.Point(525, 511);
            this.Enroll.Name = "Enroll";
            this.Enroll.Size = new System.Drawing.Size(87, 23);
            this.Enroll.TabIndex = 4;
            this.Enroll.Text = "Enroll";
            this.Enroll.UseVisualStyleBackColor = true;
            this.Enroll.Click += new System.EventHandler(this.Enroll_Click);
            // 
            // Disconnect
            // 
            this.Disconnect.Enabled = false;
            this.Disconnect.Location = new System.Drawing.Point(618, 389);
            this.Disconnect.Name = "Disconnect";
            this.Disconnect.Size = new System.Drawing.Size(90, 23);
            this.Disconnect.TabIndex = 5;
            this.Disconnect.Text = "Disconnect";
            this.Disconnect.UseVisualStyleBackColor = true;
            this.Disconnect.Click += new System.EventHandler(this.Disconnect_Click);
            // 
            // Device
            // 
            this.Device.Enabled = false;
            this.Device.Location = new System.Drawing.Point(525, 472);
            this.Device.Name = "Device";
            this.Device.Size = new System.Drawing.Size(87, 23);
            this.Device.TabIndex = 6;
            this.Device.Text = "Device";
            this.Device.UseVisualStyleBackColor = true;
            this.Device.Click += new System.EventHandler(this.Device_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Fake Hybrid Identify",
            "Normal Hybrid Identify",
            "Security Hybrid Identify",
            "Single Identify"});
            this.comboBox1.Location = new System.Drawing.Point(617, 352);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 20);
            this.comboBox1.TabIndex = 7;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(274, 30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(229, 251);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(20, 32);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(226, 249);
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 308);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(494, 294);
            this.textBox1.TabIndex = 11;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(617, 308);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(121, 23);
            this.textBox2.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(533, 317);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 13;
            this.label1.Text = "UserID";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(529, 355);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 12);
            this.label2.TabIndex = 14;
            this.label2.Text = "Identify type";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.FingerVein);
            this.tabControl1.Location = new System.Drawing.Point(270, 5);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(240, 280);
            this.tabControl1.TabIndex = 17;
            // 
            // FingerVein
            // 
            this.FingerVein.Location = new System.Drawing.Point(4, 22);
            this.FingerVein.Name = "FingerVein";
            this.FingerVein.Size = new System.Drawing.Size(232, 254);
            this.FingerVein.TabIndex = 0;
            this.FingerVein.Text = "FingerVein";
            this.FingerVein.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.FingerPrint);
            this.tabControl2.Location = new System.Drawing.Point(14, 6);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(240, 280);
            this.tabControl2.TabIndex = 18;
            // 
            // FingerPrint
            // 
            this.FingerPrint.Location = new System.Drawing.Point(4, 22);
            this.FingerPrint.Name = "FingerPrint";
            this.FingerPrint.Size = new System.Drawing.Size(232, 254);
            this.FingerPrint.TabIndex = 0;
            this.FingerPrint.Text = "FingerPrint";
            this.FingerPrint.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(618, 472);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 23);
            this.button1.TabIndex = 19;
            this.button1.Text = "Clear";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(536, 86);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(105, 23);
            this.button2.TabIndex = 20;
            this.button2.Text = "Output FV_PIC";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(536, 139);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(105, 23);
            this.button3.TabIndex = 21;
            this.button3.Text = "Output FP_PIC";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(751, 619);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.Device);
            this.Controls.Add(this.Disconnect);
            this.Controls.Add(this.Enroll);
            this.Controls.Add(this.Verify);
            this.Controls.Add(this.Identify);
            this.Controls.Add(this.ClearFinger);
            this.Controls.Add(this.Connect);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.tabControl2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "ZKFingerVeinDemo v1.0";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Connect;
        private System.Windows.Forms.Button ClearFinger;
        private System.Windows.Forms.Button Identify;
        private System.Windows.Forms.Button Verify;
        private System.Windows.Forms.Button Enroll;
        private System.Windows.Forms.Button Disconnect;
        private System.Windows.Forms.Button Device;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage FingerVein;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage FingerPrint;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}

