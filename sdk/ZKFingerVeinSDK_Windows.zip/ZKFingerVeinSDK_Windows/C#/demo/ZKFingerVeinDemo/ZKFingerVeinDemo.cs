﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using zkfvcsharp;
using System.Threading;
using System.IO;
using System.Runtime.InteropServices;
using Sample;
using CommonTool;
using System.Drawing.Imaging;

namespace ZKFVDemo3_CSharp
{
    
    public partial class Form1 : Form
    {
        IntPtr m_hDBCache = IntPtr.Zero;
        IntPtr m_hDevice = IntPtr.Zero;
        IntPtr FormHandle = IntPtr.Zero;

        const int ENROLL_CNT=3;
        const int MAX_TEMPLATE_SIZE = 2048;
        private static int MAX_TEMPLATE_SIZE_FV = 1024;

        /*
         #define WM_FINGER_RECEIVED		(WM_USER+103)
        #define WM_VEIN_RECEIVED		(WM_USER+104)
        #define WM_USER                         0x0400   
         */
        int 	 m_imgFPWidth;
	    int 	 m_imgFPHeight;
	    int 	 m_imgFVWidth;
	    int 	 m_imgFVHeight;


        int     UserID=0;

        bool m_bIdentify=false;
        bool m_bStopThread=false;
        bool m_bRegister=false;


        byte[][] m_preRegFPTmps = null;
	    int[]m_nPreRegFPTmpSize=new int[3];
        byte[][] m_preRegFVTmps = null;
	    int[]m_nPreRegFVTmpSize=new int[3];
	    int			m_nEnrollIndex;


	    //verify sample
        byte[][] m_lastRegFPTmps = null;
	    int[]m_nlastRegFPTmpSize=new int[3];
        byte[][] m_lastRegFVTmps = null;
	    int[]m_nlastRegFVTmpSize=new int[3];

		    //登记图片的存放
        byte[][] m_regFpImage = null;
	    int[]m_nregFpImageSize=new int[3];
        byte[][] m_regFvImage = null;
	    int[]m_nregFvImageSize=new int[3];


        byte[] pBuffFPImage = null;
        byte[] pBuffFVImage = null;
        byte[] szFPTmp = null;
        byte[] szFVTmp = null;





        Thread m_hThreadWork;


        public const int CUSTOM_MESSAGE_OK = 0x0400 + 103;
        //public const  int WM_VEIN_RECEIVED = 0x0400 + 104;




        [DllImport("user32.dll", EntryPoint = "SendMessageA")]
        public static extern int SendMessage(IntPtr hwnd, int wMsg, int FP_TempSize, int FV_TempSize);


        private void DoRegister()
        { 
        
        
        }


        private void ThreadCapture()
        {
            m_bStopThread = false;
            pBuffFPImage = new byte[m_imgFPWidth * m_imgFPHeight];
            //pBuffFPImage = new byte[200];
            //pBuffFVImage = new byte[200];
            int nFPImageSize = 0;
            pBuffFVImage = new byte[m_imgFVWidth * m_imgFVHeight];
            int nFVImageSize = 0;
            szFPTmp = new byte[MAX_TEMPLATE_SIZE];
            Array.Clear(szFPTmp, 0, MAX_TEMPLATE_SIZE);
            int nFPTmpSize = 0;
            szFVTmp = new byte[MAX_TEMPLATE_SIZE_FV];
            Array.Clear(szFVTmp, 0, MAX_TEMPLATE_SIZE_FV);
            int nFVTmpSize = 0;
            while (!m_bStopThread)
            {
                nFPImageSize = m_imgFPHeight * m_imgFPWidth;
                nFVImageSize = m_imgFVHeight * m_imgFVWidth;
                nFPTmpSize = MAX_TEMPLATE_SIZE;
                nFVTmpSize = MAX_TEMPLATE_SIZE;
                Array.Clear(szFPTmp, 0, MAX_TEMPLATE_SIZE);
                Array.Clear(szFVTmp, 0, MAX_TEMPLATE_SIZE_FV);
                Array.Clear(pBuffFPImage,0,m_imgFPWidth * m_imgFPHeight);
                Array.Clear(pBuffFVImage,0,m_imgFVWidth * m_imgFVHeight);

                int ret = zkfv.AcquireFingerVein(m_hDevice, pBuffFPImage, pBuffFVImage, szFPTmp, ref nFPTmpSize, szFVTmp, ref nFVTmpSize);            
                if (zkfverrdef.ZKFV_ERR_OK == ret)
                {
                    SendMessage(FormHandle, CUSTOM_MESSAGE_OK, nFPTmpSize, nFVTmpSize);
                }
              
                Thread.Sleep(200);
            }
        }

        protected override void DefWndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case CUSTOM_MESSAGE_OK:
                    {
                        byte[] RotPic = new byte[m_imgFVWidth * m_imgFVHeight];
                        MemoryStream ms = new MemoryStream();
                        BitmapFormat.GetBitmap(pBuffFVImage, m_imgFVWidth, m_imgFVHeight, ref ms);                       
                        Bitmap bmp = new Bitmap(ms);            
                        this.pictureBox1.Image = bmp;
                        this.pictureBox1.Image.RotateFlip(RotateFlipType.Rotate90FlipX);


                        StringBuilder FV_Dest = new StringBuilder();                   
                        ulong InLen_FV = (ulong)(m.LParam.ToInt32());
                        ulong OutLen_FV = (ulong)(InLen_FV * 2);
                        Common.ByteToHex(ref szFVTmp, InLen_FV, ref FV_Dest, ref OutLen_FV);
                        textBox1.AppendText("FVTemp:" + "\r\n" + FV_Dest + "\r\n");


                        MemoryStream ms1 = new MemoryStream();
                        RotPic = new byte[m_imgFPWidth * m_imgFPHeight];
                        BitmapFormat.GetBitmap(pBuffFPImage, m_imgFPHeight, m_imgFPWidth, ref ms1);
                        Bitmap bmp1 = new Bitmap(ms1);
                        this.pictureBox2.Image = bmp1;


                        StringBuilder Dest_FP = new StringBuilder();
                        ulong InLen_FP = (ulong)(m.WParam.ToInt32());
                        ulong OutLen_FP = (ulong)(InLen_FP * 2);
                        Common.ByteToHex(ref szFPTmp, InLen_FP, ref Dest_FP, ref OutLen_FP);
                        textBox1.AppendText("FPTemp:" + "\r\n" + Dest_FP + "\r\n");


                        if (m_bRegister)
                        {
                            DoRegister( m.WParam.ToInt32(), m.LParam.ToInt32());
                        }
                        else
                        {
                            DoVerify(m.WParam.ToInt32(), m.LParam.ToInt32());
                        }
                    }
                    break;
                default:
                    base.DefWndProc(ref m);
                    break;
            }


        }

    

        private void DoVerify(int nFPTmpSize, int nFVTmpSize)
        {
            int fid = 0;
            int score = 0;
            if (m_bIdentify)
            {
                if (comboBox1.SelectedIndex == 0)
                {
                    if (nFPTmpSize > 0 && nFVTmpSize > 0)
                    {
                        int ret = zkfverrdef.ZKFV_ERR_OK;
                        if ((ret = zkfv.DBFakeHybridIdentify(m_hDBCache, szFPTmp, szFVTmp, ref fid, ref score)) == zkfverrdef.ZKFV_ERR_OK)
                        {
                            textBox1.AppendText("Fake-Hybrid identify succ, tid=" + fid + ",  score=" + score + "\r\n");
                        }
                        else
                        {
                            textBox1.AppendText("Fake-Hybrid identify fail, ret=" + ret + "\r\n");

                        }

                    }
                    else
                    {
                        textBox1.AppendText("Hybrid-Identify need capture fingerprint and fingervein succ! \r\n");
                    }
                }
                else if (comboBox1.SelectedIndex == 1)
                {
                    if (nFPTmpSize > 0 && nFVTmpSize > 0)
                    {
                        int ret = zkfverrdef.ZKFV_ERR_OK;
                        if ((ret = zkfv.DBNormalHybridIdentify(m_hDBCache, szFPTmp, szFVTmp, ref fid, ref score)) == zkfverrdef.ZKFV_ERR_OK)
                        {
                            textBox1.AppendText("Normal-Hybrid identify succ, tid=" + fid + ",  score=" + score + "\r\n");
                        }
                        else
                        {
                            textBox1.AppendText("Normal-Hybrid identify fail, ret=" + ret + "\r\n");
                        }

                    }
                    else
                    {
                        textBox1.AppendText("Hybrid-Identify need capture fingerprint and fingervein succ! \r\n");
                    }
                }
                else if (comboBox1.SelectedIndex == 2)
                {
                    if (nFPTmpSize > 0 && nFVTmpSize > 0)
                    {
                        int ret = zkfverrdef.ZKFV_ERR_OK;
                        if ((ret = zkfv.DBSecurityHybridIdentify(m_hDBCache, szFPTmp, szFVTmp, ref fid, ref score)) == zkfverrdef.ZKFV_ERR_OK)
                        {
                            textBox1.AppendText("Security-Hybrid identify succ, tid=" + fid + ",  score=" + score + "\r\n");
                        }
                        else
                        {
                            textBox1.AppendText("Security-Hybrid identify fail, ret=" + ret + "\r\n");
                        }

                    }
                    else
                    {
                        textBox1.AppendText("Hybrid-Identify need capture fingerprint and fingervein succ! \r\n");
                    }
                }
                else
                {
                    int ret = zkfverrdef.ZKFV_ERR_OK;
                    if (nFPTmpSize > 0 && zkfverrdef.ZKFV_ERR_OK == (ret = zkfv.DBIdentifyFP(m_hDBCache, szFPTmp, ref fid, ref score)))
                    {
                        textBox1.AppendText("identify fingerprint succ, tid=" + fid + ",  score=" + score + "\r\n");
                    }
                    else if (nFVTmpSize > 0 && zkfverrdef.ZKFV_ERR_OK == (ret = zkfv.DBIdentifyFV(m_hDBCache, szFVTmp, ref fid, ref score)))
                    {
                        textBox1.AppendText("identify finger-vein succ, tid=" + fid + ",  score=" + score + "\r\n");
                    }
                    else
                    {
                        textBox1.AppendText("Identify failed \r\n");
                    }
                }

            }
            else 
            {
                if (m_nlastRegFVTmpSize[0] <= 0 && m_nlastRegFPTmpSize[0] <= 0)
                {
                    textBox1.AppendText("no fingervein registered");
                    return;
                }
                if (nFPTmpSize > 0)
                {
                   // CString strTmp = _T("Verify fingerprint failed!\r\n");
                    int scores = 0;
                    bool m_bFP = false;
                    for (int i = 0; i < ENROLL_CNT; i++)
                    {
                        if ((scores = zkfv.DBMatchFP(m_hDBCache, m_lastRegFPTmps[i], szFPTmp)) > 0)
                        {
                            m_bFP = true;
                            textBox1.AppendText("Verify fingerprint succ, score=" + scores+"\r\n");
                            break;
                        }
                    }
                    if(!m_bFP)
                        textBox1.AppendText("Verify fingerprint failed! \r\n");                
                }
                if (nFVTmpSize > 0)
                {
                    int scores = 0;
                    bool m_bFV = false;
                    for (int i = 0; i < ENROLL_CNT; i++)
                    {
                        if ((scores = zkfv.DBMatchFV(m_hDBCache, m_lastRegFVTmps[i], szFVTmp)) > 0)
                        {
                            m_bFV = true;
                            textBox1.AppendText("Verify fingervein succ, score=" + scores + "\r\n");
                            break;
                        }                  
                    }
                    if (!m_bFV)
                        textBox1.AppendText("Verify fingervein failed! \r\n");
                }       
            }
            
        
        }

        private void DoRegister(int nFPTmpSize, int nFVTmpSize)
        {
            if (nFPTmpSize > 0 && nFVTmpSize > 0)
            {
                if (m_nEnrollIndex > 0)
                {
                    int ret_fv = 0;
                    int ret_fp = 0;
                    if (
                        (ret_fp = zkfv.DBMatchFP(m_hDBCache, m_preRegFPTmps[m_nEnrollIndex - 1], szFPTmp)) <= 0 ||
                        (ret_fv = zkfv.DBMatchFV(m_hDBCache, m_preRegFVTmps[m_nEnrollIndex - 1], szFVTmp)) <= 0
                        )
                    {
                        textBox1.AppendText("Enroll fail \r\n");
                        m_bRegister = false;
                        m_nEnrollIndex = 0;
                    }
                }
                m_regFpImage[m_nEnrollIndex] = pBuffFPImage;
                m_regFvImage[m_nEnrollIndex] = pBuffFVImage;
                m_preRegFPTmps[m_nEnrollIndex] = szFPTmp;
                m_nPreRegFPTmpSize[m_nEnrollIndex] = nFPTmpSize;
                m_preRegFVTmps[m_nEnrollIndex] = szFVTmp;
                m_nPreRegFVTmpSize[m_nEnrollIndex] = nFVTmpSize;
                m_nEnrollIndex++;
                int ret=0;
                if (m_nEnrollIndex >= 3)
                {
                    byte[] FP_Temp=new byte[2048];
                    int FP_TempLen=2048;
                    if (zkfverrdef.ZKFV_ERR_OK != (ret = zkfv.DBMergeFP(m_hDBCache, m_preRegFPTmps, FP_Temp, ref FP_TempLen)))
                    {
                        textBox1.AppendText("Enroll failed, because merge fingerprint failed!");
                        return;
                    }

                    ret = zkfv.DBAddEx(m_hDBCache, UserID, m_preRegFVTmps, FP_Temp);
                    if (zkfverrdef.ZKFV_ERR_OK == ret)
                    {

                        textBox1.AppendText("Enroll Succ!");
                        for (int i = 0; i < ENROLL_CNT; i++)
                        {
                            m_nlastRegFPTmpSize[i] = m_nPreRegFPTmpSize[i];
                            m_nlastRegFVTmpSize[i] = m_nPreRegFVTmpSize[i];
                            m_lastRegFPTmps[i] = m_preRegFPTmps[i];
                            m_lastRegFVTmps[i] = m_preRegFVTmps[i];
                        }
                    }
                    else 
                    {
                        textBox1.AppendText("AppendText fail ret:" + ret + "/r/n");
                        m_bRegister = false;
                        m_nEnrollIndex = 0;
                    }
                }
                else
                {
                    textBox1.AppendText("You need press your finger" + (ENROLL_CNT - m_nEnrollIndex) + "times \r\n");
                }
             }
           
        
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            FormHandle = this.Handle;         
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (IntPtr.Zero == m_hDevice)
            {
                if (zkfv.Init() != zkfverrdef.ZKFV_ERR_OK)
                {
                    //MessageBox.Show("Init ZKFVM fail");
                    textBox1.AppendText("Init ZKFVM fail \r\n");
                    return;
                }
                int Count = zkfv.GetDeviceCount();
                if (Count > 0)
                {
                    if ((m_hDevice = zkfv.OpenDevice(0)) == IntPtr.Zero)
                    {
                        textBox1.AppendText("Open Sensor fail \r\n");
                        zkfv.Terminate();
                        return;
                    }
                    m_hDBCache = zkfv.DBInit();
                    if (IntPtr.Zero == m_hDBCache)
                    {
                        textBox1.AppendText("Create DBCache fail \r\n");
                        zkfv.CloseDevice(m_hDevice);
                        zkfv.Terminate();
                        return;
                    }        
                    byte[] paramValue = new byte[4];
                    int reSize = 4;
                    int ret = zkfv.GetParameters(m_hDevice, 5001, paramValue, ref reSize);
                    zkfv.ByteArray2Int(paramValue, ref m_imgFVWidth);



                    reSize = 4;
                    paramValue = new byte[4];
                    zkfv.GetParameters(m_hDevice, 5002, paramValue, ref reSize);
                    zkfv.ByteArray2Int(paramValue, ref m_imgFVHeight);


                    reSize = 4;
                    paramValue = new byte[4];
                    zkfv.GetParameters(m_hDevice, 5004, paramValue, ref reSize);
                    zkfv.ByteArray2Int(paramValue, ref m_imgFPHeight);


                    reSize = 4;
                    paramValue = new byte[4];
                    zkfv.GetParameters(m_hDevice, 5005, paramValue, ref reSize);
                    zkfv.ByteArray2Int(paramValue, ref m_imgFPWidth);


                    

                    m_preRegFPTmps = new byte[ENROLL_CNT][];
                    m_preRegFVTmps = new byte[ENROLL_CNT][];
                    m_lastRegFPTmps = new byte[ENROLL_CNT][];
                    m_lastRegFVTmps = new byte[ENROLL_CNT][];
                    m_regFpImage = new byte[ENROLL_CNT][];
                    m_regFvImage = new byte[ENROLL_CNT][];


                    for (uint i = 0; i < ENROLL_CNT; i++)
                    {
                        m_preRegFPTmps[i] = new byte[MAX_TEMPLATE_SIZE];
                        m_preRegFVTmps[i] = new byte[MAX_TEMPLATE_SIZE_FV];
                        m_lastRegFPTmps[i] = new byte[MAX_TEMPLATE_SIZE];
                        m_lastRegFVTmps[i] = new byte[MAX_TEMPLATE_SIZE_FV];
                        m_regFpImage[i] = new byte[m_imgFPWidth * m_imgFPHeight];
                        m_regFvImage[i] = new byte[m_imgFPWidth * m_imgFPHeight];
                    }
                    Array.Clear(m_nPreRegFPTmpSize, 0, 3);
                    Array.Clear(m_nPreRegFVTmpSize, 0, 3);
                    Array.Clear(m_nlastRegFPTmpSize, 0, 3);
                    Array.Clear(m_nlastRegFVTmpSize, 0, 3);
                    Array.Clear(m_nregFpImageSize, 0, 3);
                    Array.Clear(m_nregFvImageSize, 0, 3);


                    m_nEnrollIndex = 0;
                    Connect.Enabled = false;
                    Disconnect.Enabled = true;
                    Enroll.Enabled = true;
                    Verify.Enabled = true;
                    Identify.Enabled = true;
                    ClearFinger.Enabled = true;
                    Device.Enabled = true;

                    m_hThreadWork = new Thread(ThreadCapture);
                    m_hThreadWork.IsBackground = true;
                    m_hThreadWork.Start();
                    textBox1.AppendText("Init Succ \r\n");
                    
                }




            }
            else
            {
                textBox1.AppendText("Already Init \r\n");
            }
            //显示SDK版本号

        }
        /*
         
         */
        private void Disconnect_Click(object sender, EventArgs e)
        {

            if (IntPtr.Zero != m_hDevice)
		    {
			    m_bStopThread = true;
			    if (null != m_hThreadWork)
			    {
                   
                    m_hThreadWork.Abort();
				    //WaitForSingleObject(m_hThreadWork, INFINITE);
				    //CloseHandle(m_hThreadWork);
				    m_hThreadWork = null;
			    }
			    if (null != m_hDBCache)
			    {
                    zkfv.DBClear(m_hDBCache);
				    //ZKFingerVein_DBFree(m_hDBCache);
				    m_hDBCache = IntPtr.Zero;
			    }
                zkfv.CloseDevice(m_hDevice);
                zkfv.Terminate();
			    m_hDevice = IntPtr.Zero;
			    //SetDlgItemText(IDC_EDIT_REPORT, _T("Close Succ"));
                textBox1.AppendText("Close Succ \r\n");
                Connect.Enabled=true;
                Disconnect.Enabled=false;
                Enroll.Enabled=false;
                Verify.Enabled=false;
                Identify.Enabled=false;
                ClearFinger.Enabled=false;
			    if (null != m_preRegFPTmps)
			    {
				    for (int i=0;i<ENROLL_CNT;i++)
				    {
                        this.m_preRegFPTmps[i]=null;
				    }
                    this.m_preRegFPTmps=null;
			    }

			    if (null != m_preRegFVTmps)
			    {
				    for (int i=0;i<ENROLL_CNT;i++)
				    {
				        this.m_preRegFVTmps[i]=null;
				    }
    				
				    this.m_preRegFVTmps = null;
			    }

			    if (null != m_regFpImage)
			    {
				    for (int i=0;i<ENROLL_CNT;i++)
				    {
					    this.m_regFpImage[i]=null;
				    }
				    this.m_regFpImage=null;
			    }

			    if (null != m_regFvImage)
			    {
				    for (int i=0;i<ENROLL_CNT;i++)
				    {
					    this.m_regFvImage[i]=null;
				    }
				    this.m_regFvImage=null;
			    }

			    if (null == m_lastRegFVTmps)
			    {
				    for (int i=0;i<ENROLL_CNT;i++)
				    {
					    this.m_lastRegFVTmps[i]=null;
				    }
				    this.m_lastRegFVTmps=null;
			    }

			    if (null == m_lastRegFPTmps)
			    {
				    for (int i=0;i<ENROLL_CNT;i++)
				    {
					    this.m_lastRegFPTmps[i]=null;
				    }
				    this.m_lastRegFPTmps=null;
			    }
		    }
		    return ;

            }

            private void Device_Click(object sender, EventArgs e)
            {              
	            m_bRegister = false;

	            if(m_hDevice == IntPtr.Zero)
	            {
		            //SetDlgItemText(IDC_EDIT_REPORT, _T("Please connect the device"));
		            //DebugLog(CString("Please connect the device"));
                    textBox1.AppendText("Please connect thr device \r\n");
		            return ;
	            }
	            //show serial number
                int Vaule_SN=0;
	            int flag = 1103; 
	            byte[] DevSN = new byte[64];
	            int size = 64;
                zkfv.GetParameters(m_hDevice, flag, DevSN, ref size);
                zkfv.ByteArray2Int(DevSN, ref Vaule_SN);

	           // ZKFingerVein_GetParameter(m_hDevice,1103,DevSN,&size);

	            //show device name
	            flag = 1102;
	            byte[] DevMame = new byte[64];
	            size = 64;
                zkfv.GetParameters(m_hDevice, flag, DevMame, ref size);
                //zkfv.ByteArray2Int(DevMame, ref Value_Name);
                string Value_Name = System.Text.Encoding.Default.GetString(DevMame); 
	           // ZKFingerVein_GetParameter(m_hDevice,1102,DevMame,&size);


	            //show firmware version
	            flag = 1201;
                int Value_Fw = 0;
	            byte[] FwVersion =new byte[3];
	            size = 3;
                zkfv.GetParameters(m_hDevice, flag, FwVersion, ref size);
                zkfv.ByteArray2Int(FwVersion, ref Value_Fw);
	            //ZKFingerVein_GetParameter(m_hDevice,1201,FwVersion,&size);	


                //StringBuilder CS=null;
               // CS.AppendFormat("DevName = %8s,SN = %8s, FwVersion = %d", Value_Name, Vaule_SN, Value_Fw);

                textBox1.AppendText("DevName=" + Value_Name + ", SN=" + Vaule_SN.ToString() + ", FwVersion=" + FwVersion[1] + "." + FwVersion[2] + "\r\n");
                textBox1.AppendText( ", SN=" + Vaule_SN.ToString() + ", FwVersion=" + FwVersion[1] + "." + FwVersion[2] + "\r\n");
                //"DevName = %8s,SN = %8s, FwVersion = %d",Value_Name,Vaule_SN,Value_Fw
	            return ;
                }

                private void ClearFinger_Click(object sender, EventArgs e)
                {
                    if (IntPtr.Zero != m_hDevice)
                    {
                        //ZKFingerVein_DBClear(m_hDBCache, BIO_TYPE_FP);
                        //ZKFingerVein_DBClear(m_hDBCache, BIO_TYPE_FV);
                        zkfv.DBClear(m_hDBCache);                   
                        textBox1.AppendText("Clear Finished \r\n");
                    }
                    else
                    {
                        //SetDlgItemText(IDC_EDIT_REPORT, _T("Please connect device first"));
                       // DebugLog(CString("Please connect device first"));
                        textBox1.AppendText("Please connect device first \r\n");
                    }
                    return;
                }

                private void Enroll_Click(object sender, EventArgs e)
                {
                    if (textBox2.Text.Length <= 0)
                    {
                        textBox1.AppendText("Please input a correct user id! \r\n");
                        return;
                    }
                    if (IntPtr.Zero != m_hDevice)
                    {
                        //CString strTemp;
                        //GetDlgItemText(IDC_EDIT_USERID, strTemp);
                        String str = textBox2.Text.ToString();
                        if (str.Length==0)
                        {
                            //SetDlgItemText(IDC_EDIT_REPORT, _T("Please input a correct user id!"));
                            //DebugLog(CString("Please input a correct user id"));
                            textBox1.AppendText("Please input a correct user id \r\n");
                            return;
                        }
                        UserID = int.Parse(str);
                        if (!m_bRegister)
                        {
                            m_bRegister = true;
                            m_nEnrollIndex = 0;
                            //SetDlgItemText(IDC_EDIT_REPORT, _T("Doing register, please press your finger 3 times!"));
                            //DebugLog(CString("Doing Rgister ,please press your finger 3 times"));
                            textBox1.AppendText("Doing Rgister ,please press your finger 3 times\r\n");
                        }
                    }
                    return;
                }

                private void button1_Click_1(object sender, EventArgs e)
                {
                    textBox1.Clear();
                }

                private void Verify_Click(object sender, EventArgs e)
                {
                    textBox1.AppendText("Start Verify\r\n");
                    //if (Common.Empty(szFPTmp, szFPTmp.Length) || Common.Empty(szFVTmp, szFVTmp.Length))
                    //{
                    //    textBox1.AppendText("No Data to Verify \r\n");
                    //    return;
                    //}
                    if (IntPtr.Zero != m_hDevice)
                    {
                        if (m_bRegister)
                        {
                            m_bRegister = false;
                            //SetDlgItemText(IDC_EDIT_REPORT, _T("Start verify last register template"));
                            //DebugLog(CString("Start verify last register template"));
                            textBox1.AppendText("Start verify last register template \r\n");
                        }
                        m_bIdentify = false;
                    }
                    return;
                }

                private void Identify_Click(object sender, EventArgs e)
                {
                    textBox1.AppendText("Start Identify \r\n");
                    if (IntPtr.Zero != m_hDevice)
                    {
                        if (m_bRegister)
                        {
                            m_bRegister = false;
                            //SetDlgItemText(IDC_EDIT_REPORT, _T("Please input your finger"));
                            //DebugLog(CString("Please input your finger"));
                            textBox1.AppendText("Please input your finger \r\n");
                        }
                        m_bIdentify = true;
                    }
                    return;
                }

                private void label1_Click(object sender, EventArgs e)
                {

                }

                private void button2_Click(object sender, EventArgs e)
                {

                    if (this.pictureBox1.Image == null)
                    {
                        textBox1.AppendText("No pic to Output \r\n");
                        return;
                    }

                    SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                    saveFileDialog1.FileName = "fingertemplate.bmp";
                    saveFileDialog1.RestoreDirectory = true;

                    DialogResult result = saveFileDialog1.ShowDialog();
                    if (result == DialogResult.OK)
                    {
                        string fileName = saveFileDialog1.FileName.ToString();
                        if (fileName != "" && fileName != null && this.pictureBox1.Image != null)
                        {
                            
                            //http://www.wischik.com/lu/programmer/1bpp.html
                            Bitmap bmp = new Bitmap(this.pictureBox1.Image.Width, this.pictureBox1.Image.Height, System.Drawing.Imaging.PixelFormat.Format24bppRgb);

                            using (Graphics g = Graphics.FromImage(bmp))
                            {
                                g.DrawImage(this.pictureBox1.Image, 0, 0, bmp.Width, bmp.Height);

                            }
                            Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
                            System.Drawing.Imaging.BitmapData bmpData = bmp.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite, bmp.PixelFormat);
                            IntPtr ptr = bmpData.Scan0;
                            int bytes = bmpData.Stride * bmpData.Height;
                            byte[] rgbValues = new byte[bytes];
                            System.Runtime.InteropServices.Marshal.Copy(ptr, rgbValues, 0, bytes);
                            Rectangle rect2 = new Rectangle(0, 0, bmp.Width, bmp.Height);

                            Bitmap bit = new Bitmap(bmp.Width, bmp.Height, System.Drawing.Imaging.PixelFormat.Format8bppIndexed);
                            System.Drawing.Imaging.BitmapData bmpData2 = bit.LockBits(rect2, System.Drawing.Imaging.ImageLockMode.ReadWrite, bit.PixelFormat);
                            IntPtr ptr2 = bmpData2.Scan0;
                            int bytes2 = bmpData2.Stride * bmpData2.Height;
                            byte[] rgbValues2 = new byte[bytes2];
                            System.Runtime.InteropServices.Marshal.Copy(ptr2, rgbValues2, 0, bytes2);
                            double colorTemp = 0;
                            for (int i = 0; i < bmpData.Height; i++)
                            {
                                for (int j = 0; j < bmpData.Width * 3; j += 3)
                                {
                                    colorTemp = rgbValues[i * bmpData.Stride + j + 2] * 0.299 + rgbValues[i * bmpData.Stride + j + 1] * 0.578 + rgbValues[i * bmpData.Stride + j] * 0.114;
                                    rgbValues2[i * bmpData2.Stride + j / 3] = (byte)colorTemp;
                                }
                            }
                            System.Runtime.InteropServices.Marshal.Copy(rgbValues2, 0, ptr2, bytes2);
                            bmp.UnlockBits(bmpData);
                            ColorPalette tempPalette;
                            {
                                using (Bitmap tempBmp = new Bitmap(1, 1, System.Drawing.Imaging.PixelFormat.Format8bppIndexed))
                                {
                                    tempPalette = tempBmp.Palette;
                                }
                                for (int i = 0; i < 256; i++)
                                {
                                    tempPalette.Entries[i] = Color.FromArgb(i, i, i);
                                }
                                bit.Palette = tempPalette;
                            }
                            bit.UnlockBits(bmpData2);

                            bit.Save(fileName, this.pictureBox1.Image.RawFormat);

                            bit.Dispose();
                        }
                    }
                }

                private void button3_Click(object sender, EventArgs e)
                {
                    if (this.pictureBox2.Image == null)
                    {
                        textBox1.AppendText("No pic to Output \r\n");
                        return;
                    }

                    SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                    saveFileDialog1.FileName = "fingerveintemplate.bmp";
                    saveFileDialog1.RestoreDirectory = true;

                    DialogResult result = saveFileDialog1.ShowDialog();
                    if (result == DialogResult.OK)
                    {
                        string fileName = saveFileDialog1.FileName.ToString();
                        if (fileName != "" && fileName != null && this.pictureBox2.Image != null)
                        {

                            //http://www.wischik.com/lu/programmer/1bpp.html
                            Bitmap bmp = new Bitmap(this.pictureBox2.Image.Width, this.pictureBox2.Image.Height, System.Drawing.Imaging.PixelFormat.Format24bppRgb);

                            using (Graphics g = Graphics.FromImage(bmp))
                            {
                                g.DrawImage(this.pictureBox2.Image, 0, 0, bmp.Width, bmp.Height);

                            }
                            Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
                            System.Drawing.Imaging.BitmapData bmpData = bmp.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite, bmp.PixelFormat);
                            IntPtr ptr = bmpData.Scan0;
                            int bytes = bmpData.Stride * bmpData.Height;
                            byte[] rgbValues = new byte[bytes];
                            System.Runtime.InteropServices.Marshal.Copy(ptr, rgbValues, 0, bytes);
                            Rectangle rect2 = new Rectangle(0, 0, bmp.Width, bmp.Height);

                            Bitmap bit = new Bitmap(bmp.Width, bmp.Height, System.Drawing.Imaging.PixelFormat.Format8bppIndexed);
                            System.Drawing.Imaging.BitmapData bmpData2 = bit.LockBits(rect2, System.Drawing.Imaging.ImageLockMode.ReadWrite, bit.PixelFormat);
                            IntPtr ptr2 = bmpData2.Scan0;
                            int bytes2 = bmpData2.Stride * bmpData2.Height;
                            byte[] rgbValues2 = new byte[bytes2];
                            System.Runtime.InteropServices.Marshal.Copy(ptr2, rgbValues2, 0, bytes2);
                            double colorTemp = 0;
                            for (int i = 0; i < bmpData.Height; i++)
                            {
                                for (int j = 0; j < bmpData.Width * 3; j += 3)
                                {
                                    colorTemp = rgbValues[i * bmpData.Stride + j + 2] * 0.299 + rgbValues[i * bmpData.Stride + j + 1] * 0.578 + rgbValues[i * bmpData.Stride + j] * 0.114;
                                    rgbValues2[i * bmpData2.Stride + j / 3] = (byte)colorTemp;
                                }
                            }
                            System.Runtime.InteropServices.Marshal.Copy(rgbValues2, 0, ptr2, bytes2);
                            bmp.UnlockBits(bmpData);
                            ColorPalette tempPalette;
                            {
                                using (Bitmap tempBmp = new Bitmap(1, 1, System.Drawing.Imaging.PixelFormat.Format8bppIndexed))
                                {
                                    tempPalette = tempBmp.Palette;
                                }
                                for (int i = 0; i < 256; i++)
                                {
                                    tempPalette.Entries[i] = Color.FromArgb(i, i, i);
                                }
                                bit.Palette = tempPalette;
                            }
                            bit.UnlockBits(bmpData2);

                            bit.Save(fileName, this.pictureBox2.Image.RawFormat);

                            bit.Dispose();
                        }
                    }
                }
            }
        }
